import React, { createContext, useContext, useState, useEffect } from 'react';
import { GameSaveData, WeaponLoadout, MaterialKey, ElementType } from '../types/game';
import { DEFAULT_SAVE_DATA } from '../data/defaultSave';
import { WEAPONS_CATALOG, getUpgradeCost, getEvolutionCost, getCraftCost } from '../data/weaponsData';
import { PRIMORDIAL_ELEMENTS_DATA, getElementUpgradeCost } from '../data/elementsData';
import { COMBAT_ACCESSORIES_CATALOG } from '../data/accessoriesData';
import { sounds } from '../utils/audio';

const STORAGE_KEY = 'WIZARD_VALLEY_SAVE_DATA_V2';

interface GameSaveContextType {
  saveData: GameSaveData;
  equippedWeaponData: typeof WEAPONS_CATALOG[0] | undefined;
  upgradeWeapon: (weaponId: string) => { success: boolean; message: string };
  evolveWeapon: (weaponId: string) => { success: boolean; message: string };
  craftWeapon: (weaponId: string) => { success: boolean; message: string };
  upgradeElement: (elementId: string) => { success: boolean; message: string };
  changeSkin: (weaponId: string, skinId: string) => void;
  equipWeapon: (weaponId: string) => void;
  applyLoadout: (loadoutId: string) => void;
  saveNewLoadout: (loadout: Omit<WeaponLoadout, 'id'>) => void;
  claimCollectionReward: (count: number, rewardCoins: number, rewardCores: number) => void;
  recordMultiplayerMatch: (won: boolean, score: number, bossKilled: boolean, goldCollected?: number, newCharacterLevel?: number) => void;
  updateCosmetics: (field: 'robeColor' | 'auraColor' | 'glowIntensity' | 'hat' | 'staffVisual' | 'back' | 'trail', value: any) => void;
  buyCosmetic: (category: 'hat' | 'staffVisual' | 'back' | 'trail', id: string, cost: number) => boolean;
  equipAccessory: (accessoryId: string) => void;
  unequipAccessory: (accessoryId: string) => void;
  buyCombatAccessory: (accessoryId: string) => { success: boolean; message: string };
  claimCombatAccessory?: (id: string) => void;
  claimAdReward: (coins?: number, dust?: number) => { coins: number; dust: number };
  claimTutorialReward: () => boolean;
  trainLevelUp: () => { success: boolean; message: string };
  updateCharacterName: (name: string) => void;
  exportSaveJson: () => string;
  importSaveJson: (json: string) => boolean;
  resetProgress: () => void;
}

const GameSaveContext = createContext<GameSaveContextType | null>(null);

export const GameSaveProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [saveData, setSaveData] = useState<GameSaveData>(() => {
    if (typeof window !== 'undefined') {
      try {
        const item = localStorage.getItem(STORAGE_KEY);
        if (item) {
          const parsed = JSON.parse(item);
          if (parsed && parsed.version === 2 && parsed.weapons) {
            return {
              ...DEFAULT_SAVE_DATA,
              ...parsed,
              character: {
                ...DEFAULT_SAVE_DATA.character,
                ...(parsed.character || {}),
                equippedAccessories: parsed.character?.equippedAccessories || ['apprentice_ring'],
              },
              accessories: parsed.accessories && parsed.accessories.length > 0 ? parsed.accessories : ['apprentice_ring'],
              elementLevels: {
                ...DEFAULT_SAVE_DATA.elementLevels,
                ...(parsed.elementLevels || {}),
              },
            };
          }
        }
      } catch (e) {
        console.warn('Failed to load save data from localStorage:', e);
      }
    }
    return DEFAULT_SAVE_DATA;
  });

  // Save to localStorage on every change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          ...saveData,
          lastSaved: new Date().toISOString(),
        }));
      } catch (e) {
        console.error('Failed to persist save:', e);
      }
    }
  }, [saveData]);

  const equippedWeaponData = WEAPONS_CATALOG.find(w => w.id === saveData.weapons.equippedId);

  const upgradeWeapon = (weaponId: string) => {
    const catalogWeapon = WEAPONS_CATALOG.find(w => w.id === weaponId);
    if (!catalogWeapon) return { success: false, message: 'Weapon not found in catalog.' };

    const owned = saveData.weapons.owned[weaponId];
    if (!owned) return { success: false, message: 'You do not own this staff yet.' };

    if (owned.upgradeLevel >= 10) {
      return { success: false, message: 'Staff is already at maximum level 10! Seek Arcane Evolution.' };
    }

    const cost = getUpgradeCost(owned.upgradeLevel, catalogWeapon.element);

    if (saveData.economy.coins < cost.coins) {
      return { success: false, message: `Insufficient gold coins (Need ${cost.coins.toLocaleString()}).` };
    }

    if (saveData.economy.materials.magic_dust < cost.magicDust) {
      return { success: false, message: `Insufficient Common Magic Dust (Need ${cost.magicDust}).` };
    }

    for (const c of cost.crystals) {
      const current = saveData.economy.materials[c.key] || 0;
      if (current < c.amount) {
        return { success: false, message: `Insufficient ${c.key.replace(/_/g, ' ')} (Need ${c.amount}).` };
      }
    }

    // Deduct
    const newMaterials = { ...saveData.economy.materials };
    newMaterials.magic_dust -= cost.magicDust;
    for (const c of cost.crystals) {
      newMaterials[c.key] -= c.amount;
    }

    const newUpgradeLevel = owned.upgradeLevel + 1;

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost.coins,
        materials: newMaterials,
      },
      weapons: {
        ...prev.weapons,
        owned: {
          ...prev.weapons.owned,
          [weaponId]: {
            ...owned,
            upgradeLevel: newUpgradeLevel,
          },
        },
      },
    }));

    sounds.playAnvil();
    setTimeout(() => sounds.playUpgrade(), 150);
    return { success: true, message: `Successfully upgraded ${catalogWeapon.name} to Level ${newUpgradeLevel}/10!` };
  };

  const evolveWeapon = (weaponId: string) => {
    const catalogWeapon = WEAPONS_CATALOG.find(w => w.id === weaponId);
    if (!catalogWeapon || !catalogWeapon.evolvedName) {
      return { success: false, message: 'This weapon cannot evolve.' };
    }

    const owned = saveData.weapons.owned[weaponId];
    if (!owned || owned.upgradeLevel < 10) {
      return { success: false, message: 'Must reach Maximum Upgrade Level 10 before Arcane Evolution!' };
    }

    if (owned.isEvolved) {
      return { success: false, message: 'Weapon has already completed Arcane Evolution.' };
    }

    const cost = getEvolutionCost(catalogWeapon);

    if (saveData.economy.coins < cost.coins) {
      return { success: false, message: `Insufficient gold coins for evolution (Need ${cost.coins.toLocaleString()}).` };
    }

    if (saveData.economy.materials.magic_dust < cost.magicDust) {
      return { success: false, message: `Insufficient Magic Dust (Need ${cost.magicDust}).` };
    }

    for (const c of cost.crystals) {
      const current = saveData.economy.materials[c.key] || 0;
      if (current < c.amount) {
        return { success: false, message: `Missing required ${c.key.replace(/_/g, ' ')} (Need ${c.amount}).` };
      }
    }

    // Deduct materials
    const newMaterials = { ...saveData.economy.materials };
    newMaterials.magic_dust -= cost.magicDust;
    for (const c of cost.crystals) {
      newMaterials[c.key] -= c.amount;
    }

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost.coins,
        materials: newMaterials,
      },
      weapons: {
        ...prev.weapons,
        owned: {
          ...prev.weapons.owned,
          [weaponId]: {
            ...owned,
            isEvolved: true,
          },
        },
      },
      collections: {
        ...prev.collections,
        achievements: prev.collections.achievements.includes('Arcane Transmutation: Evolve a staff')
          ? prev.collections.achievements
          : [...prev.collections.achievements, 'Arcane Transmutation: Evolve a staff into its Mythic form'],
      },
    }));

    sounds.playAnvil();
    setTimeout(() => sounds.playEvolveFanfare(), 250);
    return { success: true, message: `✨ ARCANE EVOLUTION COMPLETE! Wield the ${catalogWeapon.evolvedName}!` };
  };

  const craftWeapon = (weaponId: string): { success: boolean; message: string } => {
    const catalogWeapon = WEAPONS_CATALOG.find(w => w.id === weaponId);
    if (!catalogWeapon) return { success: false, message: 'Weapon not found in catalog.' };

    if (saveData.weapons.owned[weaponId]) {
      return { success: false, message: 'You already own this magical staff.' };
    }

    if (saveData.character.level < catalogWeapon.levelReq) {
      return { success: false, message: `Requires Mage Level ${catalogWeapon.levelReq} (You are Level ${saveData.character.level}).` };
    }

    const cost = getCraftCost(catalogWeapon);

    if (saveData.economy.coins < cost.coins) {
      return { success: false, message: `Insufficient gold coins (Need ${cost.coins.toLocaleString()}).` };
    }

    if (saveData.economy.materials.magic_dust < cost.magicDust) {
      return { success: false, message: `Insufficient Magic Dust (Need ${cost.magicDust}).` };
    }

    for (const c of cost.crystals) {
      const current = saveData.economy.materials[c.key] || 0;
      if (current < c.amount) {
        return { success: false, message: `Missing required ${c.key.replace(/_/g, ' ')} (Need ${c.amount}).` };
      }
    }

    // Deduct materials
    const newMaterials = { ...saveData.economy.materials };
    newMaterials.magic_dust -= cost.magicDust;
    for (const c of cost.crystals) {
      newMaterials[c.key] -= c.amount;
    }

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost.coins,
        materials: newMaterials,
      },
      weapons: {
        ...prev.weapons,
        equippedId: weaponId,
        owned: {
          ...prev.weapons.owned,
          [weaponId]: {
            upgradeLevel: 0,
            isEvolved: false,
            selectedSkin: 'default',
          },
        },
      },
      collections: {
        ...prev.collections,
        weaponsDiscovered: prev.collections.weaponsDiscovered.includes(weaponId)
          ? prev.collections.weaponsDiscovered
          : [...prev.collections.weaponsDiscovered, weaponId],
      },
    }));

    sounds.playAnvil();
    setTimeout(() => sounds.playUpgrade(), 180);
    return { success: true, message: `Masterpiece Forged! You have forged and equipped the ${catalogWeapon.name}!` };
  };

  const upgradeElement = (elementId: string): { success: boolean; message: string } => {
    const elem = PRIMORDIAL_ELEMENTS_DATA.find(e => e.id.toLowerCase() === elementId.toLowerCase());
    if (!elem) return { success: false, message: 'Element not recognized.' };

    const currentLvl = (saveData.elementLevels && saveData.elementLevels[elem.id]) || 1;
    if (currentLvl >= 10) {
      return { success: false, message: `${elem.name} is already at Maximum Primordial Mastery (Level 10)!` };
    }

    const cost = getElementUpgradeCost(currentLvl, elem.id);

    if (saveData.economy.coins < cost.coins) {
      return { success: false, message: `Insufficient gold coins (Need ${cost.coins.toLocaleString()} coins).` };
    }

    if (saveData.economy.materials.magic_dust < cost.magicDust) {
      return { success: false, message: `Insufficient Common Magic Dust (Need ${cost.magicDust}).` };
    }

    const currentCrystals = saveData.economy.materials[cost.crystalKey] || 0;
    if (currentCrystals < cost.crystalAmount) {
      return { 
        success: false, 
        message: `Insufficient ${cost.crystalKey.replace(/_/g, ' ')} (Need ${cost.crystalAmount}, you have ${currentCrystals}).` 
      };
    }

    if (cost.requiresCore && (saveData.economy.materials.ancient_core || 0) < 1) {
      return { success: false, message: `Tier 8+ Element Ascension requires 1 Ancient Core.` };
    }

    // Deduct
    const newMaterials = { ...saveData.economy.materials };
    newMaterials.magic_dust -= cost.magicDust;
    newMaterials[cost.crystalKey] -= cost.crystalAmount;
    if (cost.requiresCore) {
      newMaterials.ancient_core -= 1;
    }

    const nextLvl = currentLvl + 1;
    const newLevels = {
      ...(saveData.elementLevels || {}),
      [elem.id]: nextLvl,
    };

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost.coins,
        materials: newMaterials,
      },
      elementLevels: newLevels,
      collections: {
        ...prev.collections,
        achievements: prev.collections.achievements.includes('Elemental Ascension')
          ? prev.collections.achievements
          : [...prev.collections.achievements, 'Elemental Ascension: Attain enhanced primordial mastery'],
      },
    }));

    sounds.playAnvil();
    setTimeout(() => sounds.playElementUpgrade(), 160);

    return {
      success: true,
      message: `✨ ${elem.icon} ${elem.name} upgraded to Level ${nextLvl}! (+${(nextLvl - 1) * 12}% Power Bonus)`,
    };
  };

  const changeSkin = (weaponId: string, skinId: string) => {
    const owned = saveData.weapons.owned[weaponId];
    if (!owned) return;
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        owned: {
          ...prev.weapons.owned,
          [weaponId]: {
            ...owned,
            selectedSkin: skinId,
          },
        },
      },
    }));
    sounds.playClick();
  };

  const equipWeapon = (weaponId: string) => {
    if (!saveData.weapons.owned[weaponId]) return;
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        equippedId: weaponId,
      },
    }));
    sounds.playClick();
  };

  const applyLoadout = (loadoutId: string) => {
    const target = saveData.weapons.loadouts.find(l => l.id === loadoutId);
    if (!target) return;
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        equippedId: target.staffId,
        activeLoadoutId: target.id,
      },
      character: {
        ...prev.character,
        equippedAccessories: target.accessories && target.accessories.length > 0 
          ? target.accessories.map(a => a.toLowerCase().replace(/[^a-z0-9]/g, '_')) 
          : prev.character.equippedAccessories,
      },
    }));
    sounds.playUpgrade();
  };

  const saveNewLoadout = (loadout: Omit<WeaponLoadout, 'id'>) => {
    const newId = `loadout_${Date.now()}`;
    const item: WeaponLoadout = { ...loadout, id: newId };
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        loadouts: [...prev.weapons.loadouts, item],
        activeLoadoutId: newId,
        equippedId: item.staffId,
      },
    }));
    sounds.playClick();
  };

  const claimCollectionReward = (count: number, rewardCoins: number, rewardCores: number) => {
    if (saveData.collections.claimedMilestones.includes(count)) return;
    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins + rewardCoins,
        materials: {
          ...prev.economy.materials,
          ancient_core: prev.economy.materials.ancient_core + rewardCores,
        },
      },
      collections: {
        ...prev.collections,
        claimedMilestones: [...prev.collections.claimedMilestones, count],
      },
    }));
    sounds.playUpgrade();
  };

  const recordMultiplayerMatch = (
    won: boolean, 
    score: number, 
    bossKilled: boolean, 
    goldCollected: number = 0, 
    newCharacterLevel?: number
  ) => {
    setSaveData(prev => {
      const xpGained = score > 0 ? Math.floor(score / 4) : 100;
      const currentExp = (prev.character.xp || 0) + xpGained;
      const calculatedLevel = Math.max(
        prev.character.level,
        newCharacterLevel || 1,
        Math.floor(1 + currentExp / 500)
      );

      return {
        ...prev,
        character: {
          ...prev.character,
          level: calculatedLevel,
          xp: currentExp,
          xpToNext: calculatedLevel * 350,
        },
        economy: {
          ...prev.economy,
          coins: prev.economy.coins + (won ? 1500 : 500) + goldCollected,
          materials: {
            ...prev.economy.materials,
            magic_dust: prev.economy.materials.magic_dust + (won ? 25 : 10),
            ancient_core: bossKilled ? prev.economy.materials.ancient_core + 1 : prev.economy.materials.ancient_core,
          },
        },
        multiplayerStats: {
          ...prev.multiplayerStats,
          matchesPlayed: prev.multiplayerStats.matchesPlayed + 1,
          wins: won ? prev.multiplayerStats.wins + 1 : prev.multiplayerStats.wins,
          bossesDefeated: bossKilled ? prev.multiplayerStats.bossesDefeated + 1 : prev.multiplayerStats.bossesDefeated,
          highestScore: Math.max(prev.multiplayerStats.highestScore, score),
        },
      };
    });
  };

  const exportSaveJson = () => {
    return JSON.stringify(saveData, null, 2);
  };

  const importSaveJson = (json: string): boolean => {
    try {
      const parsed = JSON.parse(json);
      if (parsed && parsed.weapons && parsed.character && parsed.economy) {
        setSaveData(parsed);
        sounds.playUpgrade();
        return true;
      }
    } catch (e) {
      console.error(e);
    }
    return false;
  };

  const updateCosmetics = (field: 'robeColor' | 'auraColor' | 'glowIntensity' | 'hat' | 'staffVisual' | 'back' | 'trail', value: any) => {
    setSaveData(prev => ({
      ...prev,
      character: {
        ...prev.character,
        [field]: value,
      },
    }));
  };

  const buyCosmetic = (category: 'hat' | 'staffVisual' | 'back' | 'trail', id: string, cost: number): boolean => {
    if (saveData.economy.coins < cost) return false;

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost,
      },
      character: {
        ...prev.character,
        [category]: id,
        unlockedCosmetics: prev.character.unlockedCosmetics.includes(id)
          ? prev.character.unlockedCosmetics
          : [...prev.character.unlockedCosmetics, id],
      },
    }));
    sounds.playUpgrade();
    return true;
  };

  const equipAccessory = (accessoryId: string) => {
    setSaveData(prev => {
      const current = prev.character.equippedAccessories || [];
      if (current.includes(accessoryId)) return prev;
      const newSlots = current.length >= 3 ? [current[1] || current[0], current[2] || accessoryId, accessoryId] : [...current, accessoryId];
      return {
        ...prev,
        character: {
          ...prev.character,
          equippedAccessories: newSlots,
        },
      };
    });
    sounds.playClick();
  };

  const unequipAccessory = (accessoryId: string) => {
    setSaveData(prev => ({
      ...prev,
      character: {
        ...prev.character,
        equippedAccessories: (prev.character.equippedAccessories || []).filter(id => id !== accessoryId),
      },
    }));
    sounds.playClick();
  };

  const buyCombatAccessory = (accessoryId: string): { success: boolean; message: string } => {
    const item = COMBAT_ACCESSORIES_CATALOG.find(a => a.id === accessoryId);
    if (!item) return { success: false, message: 'Accessory not found in arcane registry.' };

    const ownedAccs = saveData.accessories || [];
    if (ownedAccs.includes(item.id) || ownedAccs.includes(item.name)) {
      return { success: false, message: 'You already own this enchanted relic.' };
    }

    if (saveData.character.level < item.levelReq) {
      return { success: false, message: `Requires Mage Level ${item.levelReq} (You are Lv.${saveData.character.level}).` };
    }

    if (saveData.economy.coins < item.cost.coins) {
      return { success: false, message: `Insufficient Gold (Need ${item.cost.coins.toLocaleString()}).` };
    }

    if (saveData.economy.materials.magic_dust < item.cost.magicDust) {
      return { success: false, message: `Insufficient Magic Dust (Need ${item.cost.magicDust}).` };
    }

    const newMaterials = { ...saveData.economy.materials };
    newMaterials.magic_dust -= item.cost.magicDust;

    setSaveData(prev => {
      const currentEquipped = prev.character.equippedAccessories || [];
      const newEquipped = currentEquipped.length < 3 ? [...currentEquipped, item.id] : currentEquipped;

      return {
        ...prev,
        economy: {
          ...prev.economy,
          coins: prev.economy.coins - item.cost.coins,
          materials: newMaterials,
        },
        accessories: [...(prev.accessories || []), item.id],
        character: {
          ...prev.character,
          equippedAccessories: newEquipped,
        },
        collections: {
          ...prev.collections,
          accessories: prev.collections.accessories.includes(item.name)
            ? prev.collections.accessories
            : [...prev.collections.accessories, item.name],
        },
      };
    });

    sounds.playUpgrade();
    return { success: true, message: `Acquired and attuned ${item.name}!` };
  };

  const trainLevelUp = (): { success: boolean; message: string } => {
    const currentLevel = saveData.character.level;
    const currentXp = saveData.character.xp || 0;
    const xpNeeded = currentLevel * 300;
    const costCoins = currentLevel * 150;
    const costDust = Math.max(5, currentLevel * 2);

    const hasFreeXp = currentXp >= xpNeeded;
    if (!hasFreeXp) {
      if (saveData.economy.coins < costCoins) {
        return { 
          success: false, 
          message: `Need ${xpNeeded - currentXp} more XP or ${costCoins} Gold for academy training.` 
        };
      }
      if (saveData.economy.materials.magic_dust < costDust) {
        return { 
          success: false, 
          message: `Academy training requires ${costDust} Magic Dust.` 
        };
      }
    }

    setSaveData(prev => {
      const nextLevel = prev.character.level + 1;
      const remainingXp = hasFreeXp ? currentXp - xpNeeded : currentXp;
      const nextXpToNext = nextLevel * 300;
      const newMaterials = { ...prev.economy.materials };
      if (!hasFreeXp) {
        newMaterials.magic_dust = Math.max(0, newMaterials.magic_dust - costDust);
      }

      return {
        ...prev,
        character: {
          ...prev.character,
          level: nextLevel,
          xp: remainingXp,
          xpToNext: nextXpToNext,
        },
        economy: {
          ...prev.economy,
          coins: hasFreeXp ? prev.economy.coins : Math.max(0, prev.economy.coins - costCoins),
          materials: newMaterials,
        },
      };
    });

    sounds.playUpgrade();
    return { success: true, message: `Ascension Complete! Reached Mage Level ${currentLevel + 1}!` };
  };

  const updateCharacterName = (name: string) => {
    if (!name.trim()) return;
    setSaveData(prev => ({
      ...prev,
      character: {
        ...prev.character,
        name: name.trim(),
      },
    }));
  };

  const claimAdReward = (coins = 350, dust = 10): { coins: number; dust: number } => {
    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins + coins,
        materials: {
          ...prev.economy.materials,
          magic_dust: (prev.economy.materials.magic_dust || 0) + dust,
        },
      },
    }));
    sounds.playUpgrade();
    return { coins, dust };
  };

  const claimTutorialReward = (): boolean => {
    if (saveData.progression.storyProgress > 0) return false;
    setSaveData(prev => ({
      ...prev,
      progression: {
        ...prev.progression,
        storyProgress: 1,
      },
      economy: {
        ...prev.economy,
        coins: prev.economy.coins + 300,
        materials: {
          ...prev.economy.materials,
          magic_dust: (prev.economy.materials.magic_dust || 0) + 15,
        },
      },
    }));
    sounds.playEvolveFanfare();
    return true;
  };

  const resetProgress = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem('ARCANE_CITADEL_SAVE_DATA_V1');
    } catch (e) {
      // ignore
    }
    setSaveData(DEFAULT_SAVE_DATA);
    sounds.playClick();
  };

  return (
    <GameSaveContext.Provider
      value={{
        saveData,
        equippedWeaponData,
        upgradeWeapon,
        evolveWeapon,
        craftWeapon,
        upgradeElement,
        changeSkin,
        equipWeapon,
        applyLoadout,
        saveNewLoadout,
        claimCollectionReward,
        recordMultiplayerMatch,
        updateCosmetics,
        buyCosmetic,
        equipAccessory,
        unequipAccessory,
        buyCombatAccessory,
        claimAdReward,
        claimTutorialReward,
        trainLevelUp,
        updateCharacterName,
        exportSaveJson,
        importSaveJson,
        resetProgress,
      }}
    >
      {children}
    </GameSaveContext.Provider>
  );
};

export const useGameSave = () => {
  const context = useContext(GameSaveContext);
  if (!context) throw new Error('useGameSave must be used within a GameSaveProvider');
  return context;
};
