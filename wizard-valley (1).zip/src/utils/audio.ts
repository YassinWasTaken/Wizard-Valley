/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Web Audio API synthesized SFX for Wizard Valley / Arcane Citadel
 * Features master compression, low-latency node pooling, rate-limiting, and auto-unlock.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  public enabled: boolean = true;
  private lastSoundTimes: Record<string, number> = {};

  constructor() {
    if (typeof window !== 'undefined') {
      const unlock = () => {
        this.unlockAudio();
        ['click', 'keydown', 'pointerdown', 'touchstart'].forEach(evt => {
          window.removeEventListener(evt, unlock);
        });
      };
      ['click', 'keydown', 'pointerdown', 'touchstart'].forEach(evt => {
        window.addEventListener(evt, unlock, { passive: true, once: true });
      });
    }
  }

  public unlockAudio() {
    this.initCtx();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private initCtx() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      try {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          this.ctx = new AudioCtx();
          // Master compressor to prevent distortion & glitchy popping
          this.compressor = this.ctx.createDynamicsCompressor();
          this.compressor.threshold.setValueAtTime(-18, this.ctx.currentTime);
          this.compressor.knee.setValueAtTime(24, this.ctx.currentTime);
          this.compressor.ratio.setValueAtTime(8, this.ctx.currentTime);
          this.compressor.attack.setValueAtTime(0.003, this.ctx.currentTime);
          this.compressor.release.setValueAtTime(0.15, this.ctx.currentTime);

          // Master volume
          this.masterGain = this.ctx.createGain();
          this.masterGain.gain.setValueAtTime(0.85, this.ctx.currentTime);

          this.masterGain.connect(this.compressor);
          this.compressor.connect(this.ctx.destination);
        }
      } catch (e) {
        console.warn('AudioContext initialization note:', e);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  private getDestination(): AudioNode | null {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return null;
    return this.masterGain;
  }

  private shouldThrottle(key: string, minIntervalMs: number): boolean {
    const now = performance.now();
    const last = this.lastSoundTimes[key] || 0;
    if (now - last < minIntervalMs) {
      return true;
    }
    this.lastSoundTimes[key] = now;
    return false;
  }

  playClick() {
    if (!this.enabled) return;
    if (this.shouldThrottle('click', 50)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(520, t);
      osc.frequency.exponentialRampToValueAtTime(1040, t + 0.035);
      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(t);
      osc.stop(t + 0.045);
    } catch {
      // safe fallback
    }
  }

  playAnvil() {
    if (!this.enabled) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      // High pitch metallic strike
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(1400, t);
      osc1.frequency.exponentialRampToValueAtTime(700, t + 0.22);
      gain1.gain.setValueAtTime(0.2, t);
      gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
      osc1.connect(gain1);
      gain1.connect(dest);
      osc1.start(t);
      osc1.stop(t + 0.23);

      // Deep resonance hammer blow
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(320, t);
      osc2.frequency.exponentialRampToValueAtTime(120, t + 0.35);
      gain2.gain.setValueAtTime(0.18, t);
      gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc2.connect(gain2);
      gain2.connect(dest);
      osc2.start(t);
      osc2.stop(t + 0.36);
    } catch {
      // safe fallback
    }
  }

  playUpgrade() {
    if (!this.enabled) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const notes = [349.23, 440.0, 523.25, 698.46];
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        const startT = t + idx * 0.055;
        osc.frequency.setValueAtTime(freq, startT);
        gain.gain.setValueAtTime(0.12, startT);
        gain.gain.exponentialRampToValueAtTime(0.001, startT + 0.22);
        osc.connect(gain);
        gain.connect(dest);
        osc.start(startT);
        osc.stop(startT + 0.23);
      });
    } catch {
      // safe fallback
    }
  }

  playElementUpgrade() {
    if (!this.enabled) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      // Arpeggiated radiant chord with ethereal harmonic tail
      const freqs = [392.0, 493.88, 587.33, 783.99, 987.77, 1174.66];
      freqs.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        const startT = t + idx * 0.045;
        osc.frequency.setValueAtTime(freq, startT);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.05, startT + 0.3);
        gain.gain.setValueAtTime(0.14, startT);
        gain.gain.exponentialRampToValueAtTime(0.001, startT + 0.35);
        osc.connect(gain);
        gain.connect(dest);
        osc.start(startT);
        osc.stop(startT + 0.36);
      });
    } catch {
      // safe fallback
    }
  }

  playEvolveFanfare() {
    if (!this.enabled) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const chords = [523.25, 659.25, 783.99, 1046.5];
      chords.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.5, t + 0.7);
        gain.gain.setValueAtTime(0.15, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.75 + i * 0.05);
        osc.connect(gain);
        gain.connect(dest);
        osc.start(t);
        osc.stop(t + 0.8 + i * 0.05);
      });
    } catch {
      // safe fallback
    }
  }

  playDash() {
    if (!this.enabled) return;
    if (this.shouldThrottle('dash', 80)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(360, t);
      osc.frequency.exponentialRampToValueAtTime(90, t + 0.16);
      gain.gain.setValueAtTime(0.15, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(t);
      osc.stop(t + 0.17);
    } catch {
      // safe fallback
    }
  }

  playHit(isCrit: boolean = false) {
    if (!this.enabled) return;
    if (this.shouldThrottle('hit', 40)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = isCrit ? 'sawtooth' : 'triangle';
      osc.frequency.setValueAtTime(isCrit ? 640 : 300, t);
      osc.frequency.exponentialRampToValueAtTime(70, t + (isCrit ? 0.18 : 0.1));
      gain.gain.setValueAtTime(isCrit ? 0.18 : 0.1, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + (isCrit ? 0.19 : 0.11));
      osc.connect(gain);
      gain.connect(dest);
      osc.start(t);
      osc.stop(t + (isCrit ? 0.2 : 0.12));
    } catch {
      // safe fallback
    }
  }

  playSuperEffective() {
    if (!this.enabled) return;
    if (this.shouldThrottle('superEffective', 60)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const notes = [440, 659.25, 880, 1108.73];
      notes.forEach((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        const startT = t + idx * 0.035;
        osc.frequency.setValueAtTime(freq, startT);
        gain.gain.setValueAtTime(0.1, startT);
        gain.gain.exponentialRampToValueAtTime(0.001, startT + 0.16);
        osc.connect(gain);
        gain.connect(dest);
        osc.start(startT);
        osc.stop(startT + 0.17);
      });
    } catch {
      // safe fallback
    }
  }

  playPlayerHurt() {
    if (!this.enabled) return;
    if (this.shouldThrottle('playerHurt', 100)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(170, t);
      osc.frequency.linearRampToValueAtTime(55, t + 0.18);
      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(t);
      osc.stop(t + 0.19);
    } catch {
      // safe fallback
    }
  }

  playPickup() {
    if (!this.enabled) return;
    if (this.shouldThrottle('pickup', 35)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, t);
      osc.frequency.exponentialRampToValueAtTime(987.77, t + 0.075);
      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(t);
      osc.stop(t + 0.085);
    } catch {
      // safe fallback
    }
  }

  playBossRoar() {
    if (!this.enabled) return;
    if (this.shouldThrottle('bossRoar', 500)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(110, t);
      osc.frequency.linearRampToValueAtTime(45, t + 0.45);
      gain.gain.setValueAtTime(0.24, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.48);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(t);
      osc.stop(t + 0.5);
    } catch {
      // safe fallback
    }
  }

  playCastSpell(element: string) {
    if (!this.enabled) return;
    if (this.shouldThrottle('spell_' + element, 45)) return;
    const dest = this.getDestination();
    if (!this.ctx || !dest) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const elemLower = (element || '').toLowerCase();

      if (elemLower.includes('fire')) {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(280, t);
        osc.frequency.exponentialRampToValueAtTime(90, t + 0.16);
      } else if (elemLower.includes('ice') || elemLower.includes('frost')) {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1300, t);
        osc.frequency.exponentialRampToValueAtTime(500, t + 0.15);
      } else if (elemLower.includes('lightning') || elemLower.includes('storm')) {
        osc.type = 'square';
        osc.frequency.setValueAtTime(880, t);
        osc.frequency.linearRampToValueAtTime(150, t + 0.12);
      } else if (elemLower.includes('water')) {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(340, t);
        osc.frequency.exponentialRampToValueAtTime(650, t + 0.14);
      } else if (elemLower.includes('earth')) {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(150, t);
        osc.frequency.exponentialRampToValueAtTime(60, t + 0.2);
      } else if (elemLower.includes('air') || elemLower.includes('wind')) {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, t);
        osc.frequency.linearRampToValueAtTime(320, t + 0.13);
      } else if (elemLower.includes('light')) {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1046.5, t);
        osc.frequency.exponentialRampToValueAtTime(1400, t + 0.16);
      } else {
        // Void / Shadow / Dark
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(200, t);
        osc.frequency.exponentialRampToValueAtTime(55, t + 0.22);
      }

      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(gain);
      gain.connect(dest);
      osc.start(t);
      osc.stop(t + 0.19);
    } catch {
      // safe fallback
    }
  }
}

export const sounds = new SoundEngine();
