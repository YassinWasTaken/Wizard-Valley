/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MaterialKey } from '../types/game';

export interface PrimordialElementDetail {
  id: string;
  name: string;
  keyNum: number;
  icon: string;
  color: string;
  accentBg: string;
  borderClass: string;
  strongAgainst: string[];
  weakAgainst: string[];
  description: string;
  masteryTitle: string;
  perkName: string;
  perkDescription: string;
  crystalKey: MaterialKey;
  manaCost: number;
}

export const PRIMORDIAL_ELEMENTS_DATA: PrimordialElementDetail[] = [
  {
    id: 'Fire',
    name: 'Fire',
    keyNum: 1,
    icon: '🔥',
    color: '#ef4444',
    accentBg: 'rgba(239, 68, 68, 0.12)',
    borderClass: 'border-red-500 text-red-400',
    strongAgainst: ['Ice', 'Earth'],
    weakAgainst: ['Water'],
    description: 'Blazing embers that burn targets and melt frost defenses.',
    masteryTitle: 'Infernal Pyromancer',
    perkName: 'Blazing Detonation',
    perkDescription: '+12% Damage per level & expanding explosive blast radius that ignites nearby enemies.',
    crystalKey: 'fire_crystal',
    manaCost: 10,
  },
  {
    id: 'Water',
    name: 'Water',
    keyNum: 2,
    icon: '💧',
    color: '#3b82f6',
    accentBg: 'rgba(59, 130, 246, 0.12)',
    borderClass: 'border-blue-500 text-blue-400',
    strongAgainst: ['Fire'],
    weakAgainst: ['Lightning', 'Ice'],
    description: 'Crashing torrents that extinguish flames and knock back hostile foes.',
    masteryTitle: 'Abyssal Tide Sovereign',
    perkName: 'Tidal Repulsion',
    perkDescription: '+12% Damage per level & massive tidal knockback wave that restores 5% mana on multi-hit.',
    crystalKey: 'ice_crystal', // pairs with aquatics
    manaCost: 10,
  },
  {
    id: 'Earth',
    name: 'Earth',
    keyNum: 3,
    icon: '🌿',
    color: '#84cc16',
    accentBg: 'rgba(132, 204, 22, 0.12)',
    borderClass: 'border-lime-500 text-lime-400',
    strongAgainst: ['Lightning'],
    weakAgainst: ['Fire', 'Wind'],
    description: 'Seismic stones with high mass, tectonic shockwaves, and grounded weight.',
    masteryTitle: 'Titan Earthshaker',
    perkName: 'Seismic Impact',
    perkDescription: '+12% Damage per level & heavy tectonic boulder weight that briefly staggers and knocks enemies.',
    crystalKey: 'earth_crystal',
    manaCost: 12,
  },
  {
    id: 'Lightning',
    name: 'Lightning',
    keyNum: 4,
    icon: '⚡',
    color: '#eab308',
    accentBg: 'rgba(234, 179, 8, 0.12)',
    borderClass: 'border-yellow-500 text-yellow-400',
    strongAgainst: ['Water'],
    weakAgainst: ['Earth'],
    description: 'High critical chain bolts that shock conduits with instant velocity.',
    masteryTitle: 'Tempest Stormlord',
    perkName: 'Arc Discharge',
    perkDescription: '+12% Damage per level, +4% Critical strike chance, and high-velocity electric bursts.',
    crystalKey: 'storm_crystal',
    manaCost: 12,
  },
  {
    id: 'Wind',
    name: 'Wind',
    keyNum: 5,
    icon: '💨',
    color: '#06b6d4',
    accentBg: 'rgba(6, 182, 212, 0.12)',
    borderClass: 'border-cyan-500 text-cyan-400',
    strongAgainst: ['Earth'],
    weakAgainst: ['Ice'],
    description: 'Piercing gale bursts that travel with swift velocity and slice through ranks.',
    masteryTitle: 'Zephyr Skyrunner',
    perkName: 'Gale Velocity',
    perkDescription: '+12% Damage per level, +20% faster spell flight speed, and reduced mana consumption.',
    crystalKey: 'storm_crystal',
    manaCost: 8,
  },
  {
    id: 'Ice',
    name: 'Ice',
    keyNum: 6,
    icon: '❄️',
    color: '#38bdf8',
    accentBg: 'rgba(56, 189, 248, 0.12)',
    borderClass: 'border-sky-400 text-sky-300',
    strongAgainst: ['Wind', 'Water'],
    weakAgainst: ['Fire'],
    description: 'Glacial shards that freeze and chill enemy motion to a crawl.',
    masteryTitle: 'Glacial Frostweaver',
    perkName: 'Permafrost Chill',
    perkDescription: '+12% Damage per level & prolonged frost freeze duration slowing enemy movement speed by 40%.',
    crystalKey: 'ice_crystal',
    manaCost: 12,
  },
  {
    id: 'Light',
    name: 'Light',
    keyNum: 7,
    icon: '✨',
    color: '#f59e0b',
    accentBg: 'rgba(245, 158, 11, 0.12)',
    borderClass: 'border-amber-400 text-amber-300',
    strongAgainst: ['Darkness'],
    weakAgainst: ['Darkness'],
    description: 'Pure radiant energy beam that purges corruption and pierces shadows.',
    masteryTitle: 'Solar Seraph Archon',
    perkName: 'Radiant Purge',
    perkDescription: '+12% Damage per level, wider radiant beam width, and bonus damage against dark monsters.',
    crystalKey: 'light_fragment',
    manaCost: 14,
  },
  {
    id: 'Darkness',
    name: 'Darkness',
    keyNum: 8,
    icon: '🔮',
    color: '#a855f7',
    accentBg: 'rgba(168, 85, 247, 0.12)',
    borderClass: 'border-purple-500 text-purple-400',
    strongAgainst: ['Light'],
    weakAgainst: ['Light'],
    description: 'Singularity void rift that destabilizes targets and collapses reality.',
    masteryTitle: 'Void Cataclysm Sovereign',
    perkName: 'Gravitational Singularity',
    perkDescription: '+12% Damage per level & gravity well pulse that pulls surrounding enemies toward the impact point.',
    crystalKey: 'shadow_fragment',
    manaCost: 15,
  },
];

export interface ElementUpgradeCost {
  coins: number;
  magicDust: number;
  crystalAmount: number;
  crystalKey: MaterialKey;
  requiresCore: boolean;
}

export function getElementUpgradeCost(currentLevel: number, elementId: string): ElementUpgradeCost {
  const elem = PRIMORDIAL_ELEMENTS_DATA.find(e => e.id.toLowerCase() === elementId.toLowerCase()) || PRIMORDIAL_ELEMENTS_DATA[0];
  const nextLvl = currentLevel + 1;
  const coins = 100 + (nextLvl - 1) * 220 + Math.pow(nextLvl, 1.8) * 40;
  const magicDust = 5 + (nextLvl - 1) * 4;
  const crystalAmount = 1 + Math.floor((nextLvl - 1) / 2);
  const requiresCore = nextLvl >= 8;

  return {
    coins: Math.round(coins),
    magicDust,
    crystalAmount,
    crystalKey: elem.crystalKey,
    requiresCore,
  };
}

export function getElementDamageMultiplier(level: number): number {
  return 1 + (Math.max(1, level) - 1) * 0.12;
}

export function getElementRankTitle(level: number): string {
  if (level >= 10) return 'Ascended Primordial Master';
  if (level >= 7) return 'High Archmage';
  if (level >= 5) return 'Adept Conjurer';
  if (level >= 3) return 'Journeyman Elementalist';
  return 'Apprentice Spark';
}
