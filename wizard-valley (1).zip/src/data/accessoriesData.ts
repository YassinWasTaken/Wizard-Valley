export type AccessoryType = 'Ring' | 'Amulet' | 'Crest' | 'Relic' | 'Talisman';

export interface CombatAccessoryItem {
  id: string;
  name: string;
  type: AccessoryType;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary';
  description: string;
  effectSummary: string;
  icon: string; // Emoji for universal crisp render
  cost: {
    coins: number;
    magicDust: number;
  };
  levelReq: number;
  stats: {
    bonusSpellDamagePercent?: number;
    bonusMaxHp?: number;
    bonusMaxMana?: number;
    bonusMoveSpeedPercent?: number;
    bonusGoldFindPercent?: number;
    bonusCritChancePercent?: number;
    pickupMagnetRadius?: number; // Magnet drop attraction radius in pixels
    manaCostReduction?: number;
    hasRevive?: boolean;
    bonusXpPercent?: number;
  };
}

export const COMBAT_ACCESSORIES_CATALOG: CombatAccessoryItem[] = [
  {
    id: 'apprentice_ring',
    name: 'Apprentice Ring',
    type: 'Ring',
    rarity: 'Common',
    description: 'A modest silver ring handed to novice wizards on their first day of academy initiation.',
    effectSummary: '+10 Max Mana, +6% Spell Damage',
    icon: '💍',
    cost: { coins: 0, magicDust: 0 },
    levelReq: 1,
    stats: {
      bonusMaxMana: 10,
      bonusSpellDamagePercent: 6,
    },
  },
  {
    id: 'leyline_magnet',
    name: 'Leyline Amulet',
    type: 'Amulet',
    rarity: 'Common',
    description: 'Attuned to primordial leyline vibrations, effortlessly pulling stray magical crystals toward you.',
    effectSummary: '+160px Drop Attraction Radius, +15% XP Gain',
    icon: '🧲',
    cost: { coins: 350, magicDust: 15 },
    levelReq: 2,
    stats: {
      pickupMagnetRadius: 160,
      bonusXpPercent: 15,
    },
  },
  {
    id: 'archmage_crest',
    name: 'Archmage Crest',
    type: 'Crest',
    rarity: 'Rare',
    description: 'An engraved platinum insignia carried by high elemental scholars to stabilize mana conduits.',
    effectSummary: '+14% Spell Damage, -2 Mana Cost on all spells',
    icon: '🛡️',
    cost: { coins: 650, magicDust: 25 },
    levelReq: 3,
    stats: {
      bonusSpellDamagePercent: 14,
      manaCostReduction: 2,
    },
  },
  {
    id: 'dragon_eye_relic',
    name: 'Dragon Eye Relic',
    type: 'Relic',
    rarity: 'Rare',
    description: 'A fossilized dragon cornea that pulses with volcanic fury, pinpointing enemy weak spots.',
    effectSummary: '+18% Spell Damage, +12% Critical Strike Chance',
    icon: '👁️',
    cost: { coins: 850, magicDust: 35 },
    levelReq: 4,
    stats: {
      bonusSpellDamagePercent: 18,
      bonusCritChancePercent: 12,
    },
  },
  {
    id: 'glacial_heart',
    name: 'Glacial Heart Talisman',
    type: 'Talisman',
    rarity: 'Rare',
    description: 'Infused with permafrost shards from the highest peak of the Valley, shielding its wielder from harm.',
    effectSummary: '+35 Max Health, +15 Max Mana',
    icon: '❄️',
    cost: { coins: 900, magicDust: 40 },
    levelReq: 5,
    stats: {
      bonusMaxHp: 35,
      bonusMaxMana: 15,
    },
  },
  {
    id: 'golden_scarab',
    name: 'Scarab of Midas',
    type: 'Relic',
    rarity: 'Epic',
    description: 'An ancient gilded scarab that transforms defeated monster remnants into lustrous citadel gold.',
    effectSummary: '+45% Citadel Gold from drops, +10% Move Speed',
    icon: '🪲',
    cost: { coins: 1200, magicDust: 50 },
    levelReq: 6,
    stats: {
      bonusGoldFindPercent: 45,
      bonusMoveSpeedPercent: 10,
    },
  },
  {
    id: 'storm_conduit',
    name: 'Storm Conduit Signet',
    type: 'Ring',
    rarity: 'Epic',
    description: 'Captures tempest lightning in a spinning gyroscopic band, propelling you across the arena.',
    effectSummary: '+20% Movement Speed, +15% Spell Damage',
    icon: '⚡',
    cost: { coins: 1500, magicDust: 65 },
    levelReq: 8,
    stats: {
      bonusMoveSpeedPercent: 20,
      bonusSpellDamagePercent: 15,
    },
  },
  {
    id: 'void_heart',
    name: 'Abyssal Void Heart',
    type: 'Relic',
    rarity: 'Epic',
    description: 'A pulsating shard from beyond the rift that siphons spiritual energy from fallen adversaries.',
    effectSummary: '+25 Max HP, +25 Max Mana, +15% Crit Chance',
    icon: '🖤',
    cost: { coins: 2000, magicDust: 90 },
    levelReq: 10,
    stats: {
      bonusMaxHp: 25,
      bonusMaxMana: 25,
      bonusCritChancePercent: 15,
    },
  },
  {
    id: 'phoenix_feather',
    name: 'Phoenix Dawn Feather',
    type: 'Relic',
    rarity: 'Legendary',
    description: 'A blazing celestial feather that bursts into flames upon taking fatal damage, defying death once per arena match.',
    effectSummary: 'Second Life: Revives once upon death with 50% HP & shockwave',
    icon: '🪶',
    cost: { coins: 3000, magicDust: 150 },
    levelReq: 12,
    stats: {
      hasRevive: true,
      bonusMaxHp: 20,
      bonusSpellDamagePercent: 10,
    },
  },
];

// Helper to normalize accessory ID or legacy names
export function getAccessoryByIdOrName(idOrName: string): CombatAccessoryItem | undefined {
  if (!idOrName) return undefined;
  const normalized = idOrName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  return COMBAT_ACCESSORIES_CATALOG.find(
    a => a.id === idOrName || a.id === normalized || a.name.toLowerCase() === idOrName.toLowerCase()
  );
}

// Compute total cumulative stat modifiers from equipped accessories
export function calculateCumulativeAccessoryStats(equippedIds: string[]) {
  const totals = {
    bonusSpellDamagePercent: 0,
    bonusMaxHp: 0,
    bonusMaxMana: 0,
    bonusMoveSpeedPercent: 0,
    bonusGoldFindPercent: 0,
    bonusCritChancePercent: 0,
    pickupMagnetRadius: 45, // default base attraction
    manaCostReduction: 0,
    hasRevive: false,
    bonusXpPercent: 0,
  };

  equippedIds.forEach(id => {
    const acc = getAccessoryByIdOrName(id);
    if (!acc) return;
    const s = acc.stats;
    if (s.bonusSpellDamagePercent) totals.bonusSpellDamagePercent += s.bonusSpellDamagePercent;
    if (s.bonusMaxHp) totals.bonusMaxHp += s.bonusMaxHp;
    if (s.bonusMaxMana) totals.bonusMaxMana += s.bonusMaxMana;
    if (s.bonusMoveSpeedPercent) totals.bonusMoveSpeedPercent += s.bonusMoveSpeedPercent;
    if (s.bonusGoldFindPercent) totals.bonusGoldFindPercent += s.bonusGoldFindPercent;
    if (s.bonusCritChancePercent) totals.bonusCritChancePercent += s.bonusCritChancePercent;
    if (s.pickupMagnetRadius) totals.pickupMagnetRadius = Math.max(totals.pickupMagnetRadius, s.pickupMagnetRadius);
    if (s.manaCostReduction) totals.manaCostReduction += s.manaCostReduction;
    if (s.hasRevive) totals.hasRevive = true;
    if (s.bonusXpPercent) totals.bonusXpPercent += s.bonusXpPercent;
  });

  return totals;
}
