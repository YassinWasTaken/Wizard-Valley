/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Flame, 
  Shield, 
  Zap, 
  ArrowUpCircle, 
  Check, 
  AlertCircle, 
  X, 
  Coins, 
  ChevronRight,
  TrendingUp,
  Award
} from 'lucide-react';
import { useGameSave } from '../context/GameSaveContext';
import { 
  PRIMORDIAL_ELEMENTS_DATA, 
  getElementUpgradeCost, 
  getElementDamageMultiplier,
  getElementRankTitle,
  PrimordialElementDetail 
} from '../data/elementsData';
import { MATERIALS } from '../data/materialsData';
import { sounds } from '../utils/audio';

interface ElementSanctumModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultElementId?: string;
}

export const ElementSanctumModal: React.FC<ElementSanctumModalProps> = ({
  isOpen,
  onClose,
  defaultElementId = 'Fire',
}) => {
  const { saveData, upgradeElement } = useGameSave();
  const [selectedElementId, setSelectedElementId] = useState<string>(defaultElementId);
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [upgradingAnim, setUpgradingAnim] = useState(false);

  if (!isOpen) return null;

  const selectedElem: PrimordialElementDetail = 
    PRIMORDIAL_ELEMENTS_DATA.find(e => e.id.toLowerCase() === selectedElementId.toLowerCase()) || 
    PRIMORDIAL_ELEMENTS_DATA[0];

  const currentLevel = (saveData.elementLevels && saveData.elementLevels[selectedElem.id]) || 1;
  const isMaxLevel = currentLevel >= 10;
  const upgradeCost = !isMaxLevel ? getElementUpgradeCost(currentLevel, selectedElem.id) : null;

  const currentMultiplier = getElementDamageMultiplier(currentLevel);
  const nextMultiplier = getElementDamageMultiplier(currentLevel + 1);
  const rankTitle = getElementRankTitle(currentLevel);

  const crystalMeta = upgradeCost ? MATERIALS[upgradeCost.crystalKey] : null;
  const currentCrystals = upgradeCost ? (saveData.economy.materials[upgradeCost.crystalKey] || 0) : 0;
  const currentDust = saveData.economy.materials.magic_dust || 0;
  const currentCores = saveData.economy.materials.ancient_core || 0;
  const currentCoins = saveData.economy.coins || 0;

  const canAfford = upgradeCost ? (
    currentCoins >= upgradeCost.coins &&
    currentDust >= upgradeCost.magicDust &&
    currentCrystals >= upgradeCost.crystalAmount &&
    (!upgradeCost.requiresCore || currentCores >= 1)
  ) : false;

  const handleUpgrade = () => {
    setUpgradingAnim(true);
    const result = upgradeElement(selectedElem.id);
    setTimeout(() => {
      setUpgradingAnim(false);
      setStatusMessage({ text: result.message, isError: !result.success });
    }, 280);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 via-purple-600 to-cyan-500 p-0.5 shadow-lg">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold font-cinzel text-slate-100 flex items-center gap-2">
                <span>Primordial Element Sanctum</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-700/60">
                  Mastery Upgrades
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Ascend your elemental schools to amplify spell damage, blast radii, and elemental passive perks.
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Currency Quick Bar */}
        <div className="px-5 py-2.5 bg-slate-950/60 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4 text-slate-300">
            <span className="text-slate-400 font-medium">Arcane Wealth:</span>
            <span className="flex items-center gap-1 font-mono font-bold text-amber-400">
              🪙 {currentCoins.toLocaleString()}
            </span>
            <span className="flex items-center gap-1 font-mono font-bold text-cyan-300">
              ✨ {currentDust} Magic Dust
            </span>
            <span className="flex items-center gap-1 font-mono font-bold text-purple-300">
              🔮 {currentCores} Ancient Cores
            </span>
          </div>

          {statusMessage && (
            <div
              className={`px-3 py-1 rounded text-xs font-semibold flex items-center gap-1.5 ${
                statusMessage.isError
                  ? 'bg-red-950/90 text-red-300 border border-red-800'
                  : 'bg-emerald-950/90 text-emerald-300 border border-emerald-800'
              }`}
            >
              {statusMessage.isError ? <AlertCircle className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
              <span>{statusMessage.text}</span>
            </div>
          )}
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* Left Column: 8 Elements Grid Selector (5 cols) */}
          <div className="md:col-span-5 space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 font-cinzel">
              Select Element School
            </span>

            <div className="grid grid-cols-2 gap-2">
              {PRIMORDIAL_ELEMENTS_DATA.map(elem => {
                const lvl = (saveData.elementLevels && saveData.elementLevels[elem.id]) || 1;
                const isSelected = selectedElem.id === elem.id;
                const isMax = lvl >= 10;

                return (
                  <button
                    key={elem.id}
                    onClick={() => {
                      sounds.playClick();
                      setSelectedElementId(elem.id);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between h-24 ${
                      isSelected
                        ? 'border-amber-400 bg-slate-800/90 shadow-lg ring-2 ring-amber-400/40'
                        : 'border-slate-800 bg-slate-950/70 hover:border-slate-700 hover:bg-slate-900/60'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="text-2xl">{elem.icon}</span>
                      <span
                        className="text-[10px] font-bold font-mono px-1.5 py-0.5 rounded border"
                        style={{
                          backgroundColor: `${elem.color}20`,
                          borderColor: `${elem.color}50`,
                          color: elem.color,
                        }}
                      >
                        Lv. {lvl}/10
                      </span>
                    </div>

                    <div>
                      <div className="text-sm font-bold text-white font-cinzel flex items-center justify-between">
                        <span>{elem.name}</span>
                        {isMax && <Award className="w-3.5 h-3.5 text-amber-400" />}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        +{Math.round((lvl - 1) * 12)}% Power
                      </div>
                    </div>

                    {/* Active highlight glow */}
                    {isSelected && (
                      <div
                        className="absolute inset-x-0 bottom-0 h-1"
                        style={{ backgroundColor: elem.color }}
                      />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Column: Selected Element Details & Upgrade Workbench (7 cols) */}
          <div className="md:col-span-7 bg-slate-950/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-4 shadow-inner">
            <div className="space-y-4">
              {/* Element Header Banner */}
              <div
                className="p-4 rounded-xl border relative overflow-hidden"
                style={{
                  backgroundColor: selectedElem.accentBg,
                  borderColor: `${selectedElem.color}50`,
                }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{selectedElem.icon}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded border"
                          style={{
                            backgroundColor: `${selectedElem.color}30`,
                            borderColor: `${selectedElem.color}80`,
                            color: selectedElem.color,
                          }}
                        >
                          {selectedElem.masteryTitle}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">
                          Rank: {rankTitle}
                        </span>
                      </div>
                      <h3 className="text-2xl font-black font-cinzel text-white mt-1">
                        {selectedElem.name} Mastery (Level {currentLevel}/10)
                      </h3>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-300 mt-2.5 leading-relaxed">
                  {selectedElem.description}
                </p>
              </div>

              {/* Stat Multiplier Comparison */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-400">Current Element Multiplier</span>
                  <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
                    {Math.round(currentMultiplier * 100)}%
                  </div>
                  <span className="text-[10px] text-slate-400">
                    +{Math.round((currentMultiplier - 1) * 100)}% Bonus Damage
                  </span>
                </div>

                <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800">
                  <span className="text-[11px] text-slate-400">Next Upgrade Multiplier</span>
                  <div className="text-xl font-bold font-mono text-amber-400 mt-0.5">
                    {isMaxLevel ? 'MAXED' : `${Math.round(nextMultiplier * 100)}%`}
                  </div>
                  <span className="text-[10px] text-amber-400">
                    {isMaxLevel ? 'Primordial Peak' : `+12% incremental boost`}
                  </span>
                </div>
              </div>

              {/* Unique Element Perk */}
              <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-xl space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider" style={{ color: selectedElem.color }}>
                  <Zap className="w-4 h-4" />
                  <span>Elemental Perk: {selectedElem.perkName}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {selectedElem.perkDescription}
                </p>
              </div>

              {/* Progress Level Bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-400">Mastery Progress</span>
                  <span className="text-amber-400 font-mono">{currentLevel} / 10</span>
                </div>
                <div className="w-full h-3 bg-slate-900 rounded-full border border-slate-800 overflow-hidden flex p-0.5 gap-1">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div
                      key={i}
                      className="flex-1 rounded-sm transition-all"
                      style={{
                        backgroundColor: i < currentLevel ? selectedElem.color : 'rgba(255,255,255,0.06)',
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Upgrade Action & Cost Area */}
            <div className="pt-3 border-t border-slate-800 space-y-3">
              {!isMaxLevel && upgradeCost ? (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    {/* Gold Cost */}
                    <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                      <div className="text-[10px] text-slate-400">Citadel Gold</div>
                      <div className={`font-mono font-bold mt-0.5 ${currentCoins >= upgradeCost.coins ? 'text-amber-400' : 'text-red-400'}`}>
                        {currentCoins.toLocaleString()} / {upgradeCost.coins.toLocaleString()}
                      </div>
                    </div>

                    {/* Magic Dust Cost */}
                    <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                      <div className="text-[10px] text-slate-400">Magic Dust</div>
                      <div className={`font-mono font-bold mt-0.5 ${currentDust >= upgradeCost.magicDust ? 'text-cyan-300' : 'text-red-400'}`}>
                        {currentDust} / {upgradeCost.magicDust}
                      </div>
                    </div>

                    {/* Elemental Crystals */}
                    <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                      <div className="text-[10px] text-slate-400 truncate">
                        {crystalMeta?.name || 'Crystal'}
                      </div>
                      <div className={`font-mono font-bold mt-0.5 ${currentCrystals >= upgradeCost.crystalAmount ? 'text-emerald-400' : 'text-red-400'}`}>
                        {currentCrystals} / {upgradeCost.crystalAmount}
                      </div>
                    </div>

                    {/* Ancient Core (if high tier) */}
                    <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 text-center">
                      <div className="text-[10px] text-slate-400">Ancient Core</div>
                      <div className={`font-mono font-bold mt-0.5 ${!upgradeCost.requiresCore || currentCores >= 1 ? 'text-purple-400' : 'text-red-400'}`}>
                        {upgradeCost.requiresCore ? `${currentCores} / 1` : 'Not Needed'}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleUpgrade}
                    disabled={!canAfford || upgradingAnim}
                    className={`w-full py-3 px-4 rounded-xl font-bold font-cinzel text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg ${
                      canAfford && !upgradingAnim
                        ? 'bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 hover:shadow-amber-500/25 scale-[1.01]'
                        : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-60'
                    }`}
                  >
                    <ArrowUpCircle className="w-5 h-5" />
                    <span>
                      {upgradingAnim
                        ? 'Channeling Primordial Energy...'
                        : `Ascend ${selectedElem.name} to Level ${currentLevel + 1}`}
                    </span>
                  </button>
                </>
              ) : (
                <div className="p-4 bg-amber-950/50 border border-amber-600/50 rounded-xl text-center space-y-1">
                  <div className="text-amber-300 font-bold font-cinzel flex items-center justify-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>PRIMORDIAL MASTERY ACHIEVED</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    This element has achieved Level 10 Transcendence with maximum destructive power and passive utility.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
