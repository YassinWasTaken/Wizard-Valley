import React, { useState } from 'react';
import { 
  Play, 
  Hammer, 
  Layers, 
  BookOpen, 
  Sparkles, 
  Save, 
  Volume2, 
  VolumeX, 
  Shield, 
  Flame, 
  ChevronRight, 
  Crown, 
  Palette, 
  GraduationCap, 
  HelpCircle 
} from 'lucide-react';
import { useGameSave } from '../context/GameSaveContext';
import { sounds } from '../utils/audio';
import { ElementSanctumModal } from './ElementSanctumModal';
import { TutorialModal } from './TutorialModal';

interface StartMenuViewProps {
  onSelectScreen: (screen: 'room_settings' | 'forge' | 'loadouts' | 'collection' | 'arena') => void;
  onOpenSaveModal: () => void;
  onOpenAtelierModal: () => void;
}

export const StartMenuView: React.FC<StartMenuViewProps> = ({
  onSelectScreen,
  onOpenSaveModal,
  onOpenAtelierModal,
}) => {
  const { saveData, equippedWeaponData, trainLevelUp } = useGameSave();
  const [sfxOn, setSfxOn] = useState(true);
  const [isSanctumOpen, setIsSanctumOpen] = useState(false);
  const [isTutorialOpen, setIsTutorialOpen] = useState(false);
  const [trainingNotice, setTrainingNotice] = useState<{ text: string; isError?: boolean } | null>(null);

  const toggleSound = () => {
    sounds.enabled = !sfxOn;
    setSfxOn(!sfxOn);
    if (!sfxOn) sounds.playClick();
  };

  const character = saveData.character;
  const ownedEquipped = saveData.weapons.owned[saveData.weapons.equippedId];
  const staffBase = ownedEquipped?.isEvolved && equippedWeaponData?.evolvedName 
    ? equippedWeaponData.evolvedName 
    : (equippedWeaponData?.name || 'Apprentice Staff');
  const equippedStaff = ownedEquipped && ownedEquipped.upgradeLevel > 0 
    ? `+${ownedEquipped.upgradeLevel} ${staffBase}` 
    : staffBase;

  const xpNeeded = character.xpToNext || (character.level * 300);
  const hasFreeLevelUp = (character.xp || 0) >= xpNeeded;
  const trainingCostCoins = character.level * 150;

  const handleTrain = () => {
    const res = trainLevelUp();
    setTrainingNotice({ text: res.message, isError: !res.success });
    setTimeout(() => setTrainingNotice(null), 3000);
  };

  return (
    <div className="relative h-full flex flex-col justify-between items-center py-2 sm:py-3 px-2 sm:px-4 max-w-5xl mx-auto w-full overflow-hidden select-none">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden flex items-center justify-center">
        <div className="w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-3xl animate-pulse" />
        <div className="w-[400px] h-[400px] bg-amber-500/10 rounded-full blur-3xl -top-10" />
      </div>

      {/* Top Header Bar - With Live Currencies & Level Overview */}
      <div className="w-full flex items-center justify-between z-10 gap-2 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-600 via-purple-600 to-cyan-500 p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-[5px] flex items-center justify-center">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
            </div>
          </div>
          <span className="font-cinzel text-xs sm:text-sm font-bold tracking-wider text-slate-300 uppercase">
            Wizard Valley
          </span>
        </div>

        {/* Live Top Status Overview Badge */}
        <div className="flex items-center gap-2 sm:gap-3 bg-slate-950/80 border border-slate-800 px-2.5 sm:px-3 py-1 rounded-full text-[11px] sm:text-xs">
          <span className="text-purple-300 font-semibold">Lv.{character.level} Mage</span>
          <span className="text-slate-600">·</span>
          <span className="text-amber-400 font-mono font-bold">💰 {saveData.economy.coins.toLocaleString()} G</span>
          <span className="text-slate-600 hidden xs:inline">·</span>
          <span className="text-cyan-300 font-mono font-semibold hidden xs:inline">✨ {saveData.economy.materials.magic_dust || 0} Dust</span>
        </div>

        {/* Quick Nav Utility Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Tutorial / How to Play */}
          <button
            onClick={() => {
              sounds.playClick();
              setIsTutorialOpen(true);
            }}
            className="px-2.5 py-1 text-xs font-semibold text-cyan-300 hover:text-white bg-cyan-950/70 hover:bg-cyan-900 border border-cyan-700/60 rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-sm"
          >
            <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
            <span>Tutorial</span>
          </button>

          {/* Elements Sanctum */}
          <button
            onClick={() => {
              setIsSanctumOpen(true);
              sounds.playClick();
            }}
            className="px-2.5 py-1 text-xs font-semibold text-purple-300 hover:text-white bg-purple-950/60 hover:bg-purple-900 border border-purple-700/60 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
          >
            <Flame className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">Elements</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            aria-label={sfxOn ? "Mute audio" : "Enable audio"}
            className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-900/80 rounded-lg border border-slate-800 transition-colors cursor-pointer"
            title={sfxOn ? "Mute Sound" : "Unmute Sound"}
          >
            {sfxOn ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Save & Backup */}
          <button
            onClick={() => {
              onOpenSaveModal();
              sounds.playClick();
            }}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors cursor-pointer"
            title="Save & Backup"
          >
            <Save className="w-3.5 h-3.5 text-amber-400" />
          </button>
        </div>
      </div>

      {/* Main Centerpiece Area - Scaled to fit screen without scrolling */}
      <div className="w-full max-w-xl flex flex-col items-center text-center my-auto z-10 py-1 space-y-3 shrink min-h-0">
        {/* Title */}
        <div className="space-y-0.5">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[10px] font-semibold tracking-wider uppercase">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Fast 8-Element Spell Arena</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black font-cinzel tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-amber-100 via-amber-300 to-amber-600 drop-shadow">
            WIZARD VALLEY
          </h1>
        </div>

        {/* Wizard Snapshot Card */}
        <div className="bg-slate-950/85 border border-slate-800 hover:border-purple-500/40 p-3 sm:p-3.5 rounded-2xl shadow-xl backdrop-blur-md w-full transition-all">
          <div className="flex items-center gap-3 text-left">
            <div 
              className="relative w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border border-slate-700/80 overflow-hidden shadow-inner"
              style={{
                backgroundColor: character.robeColor || '#1e1b4b',
                boxShadow: `0 0 14px ${character.auraColor || '#a855f7'}40`,
              }}
            >
              <div className="text-xl select-none">🧙‍♂️</div>
              <div 
                className="absolute inset-0 rounded-xl border pointer-events-none animate-pulse"
                style={{ borderColor: character.auraColor || '#c084fc' }}
              />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-100 font-cinzel text-sm truncate">
                  {character.name}
                </h3>
                <span className="text-[11px] px-2 py-0.2 rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-300 font-semibold tabular-nums">
                  Mage Lv. {character.level}
                </span>
              </div>

              {/* Compact XP Progress Bar */}
              <div className="mt-1 space-y-0.5">
                <div className="flex justify-between text-[9px] text-slate-400">
                  <span className="text-purple-300 font-medium">EXP</span>
                  <span className="font-mono text-purple-200">{character.xp || 0} / {xpNeeded}</span>
                </div>
                <div className="w-full h-1 bg-slate-950 rounded-full border border-purple-950 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-600 via-pink-500 to-amber-400 transition-all duration-300"
                    style={{ width: `${Math.min(100, Math.max(0, ((character.xp || 0) / xpNeeded) * 100))}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between mt-1 text-[11px] text-slate-300">
                <span className="text-amber-400 font-medium">💰 {saveData.economy.coins.toLocaleString()} G</span>
                <span className="text-cyan-300 truncate max-w-[150px]">🪄 {equippedStaff}</span>
              </div>
            </div>
          </div>

          {/* Training Notification */}
          {trainingNotice && (
            <div className={`mt-1.5 py-0.5 px-2 rounded text-[11px] font-semibold text-center ${
              trainingNotice.isError ? 'bg-red-950/80 border border-red-800 text-red-300' : 'bg-emerald-950/80 border border-emerald-800 text-emerald-300'
            }`}>
              {trainingNotice.text}
            </div>
          )}

          {/* Quick Actions Under Card */}
          <div className="grid grid-cols-2 gap-1.5 mt-2">
            <button
              onClick={handleTrain}
              className={`py-1 px-2 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center gap-1 cursor-pointer shadow ${
                hasFreeLevelUp
                  ? 'bg-gradient-to-r from-amber-400 to-amber-300 text-slate-950 animate-pulse'
                  : 'bg-purple-950/70 hover:bg-purple-900 border border-purple-700/60 text-purple-200'
              }`}
            >
              <Sparkles className="w-3 h-3" />
              <span className="truncate">
                {hasFreeLevelUp ? `Ascend Lv.${character.level + 1} (Free)` : `Train Lv.${character.level + 1} (${trainingCostCoins}G)`}
              </span>
            </button>

            <button
              onClick={() => {
                onOpenAtelierModal();
                sounds.playClick();
              }}
              className="py-1 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[11px] font-semibold text-slate-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
            >
              <Palette className="w-3 h-3 text-amber-400" />
              <span>Atelier & Relics</span>
            </button>
          </div>
        </div>

        {/* PRIMARY CALL TO ACTION: Quick Play Button (1-Click Battle) */}
        <div className="w-full space-y-2">
          <button
            onClick={() => {
              onSelectScreen('arena');
              sounds.playClick();
            }}
            className="w-full py-3 sm:py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-base sm:text-lg font-cinzel shadow-lg shadow-amber-500/20 hover:shadow-amber-500/35 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between border border-amber-200"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-slate-950/20 flex items-center justify-center">
                <Play className="w-5 h-5 text-slate-950 fill-current" />
              </div>
              <div className="text-left">
                <div className="tracking-wide">QUICK PLAY</div>
                <div className="text-[10px] font-sans font-semibold text-slate-900/80">Jump Straight into Arena Combat</div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-950" />
          </button>

          {/* SECONDARY ROW: Clean, Compact 4-Card Grid */}
          <div className="grid grid-cols-2 gap-2">
            {/* Forge & Weapons */}
            <button
              onClick={() => {
                onSelectScreen('forge');
                sounds.playClick();
              }}
              className="p-2 sm:p-2.5 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-amber-800/60 hover:border-amber-500 text-left transition-all cursor-pointer flex items-center gap-2"
            >
              <div className="w-7 h-7 rounded-lg bg-amber-950/80 border border-amber-700/60 flex items-center justify-center shrink-0">
                <Hammer className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="min-w-0">
                <div className="font-cinzel text-xs font-bold text-slate-100 truncate">Arcane Forge</div>
                <div className="text-[9px] text-slate-400 truncate">Craft & Upgrade</div>
              </div>
            </button>

            {/* Custom Room Settings */}
            <button
              onClick={() => {
                onSelectScreen('room_settings');
                sounds.playClick();
              }}
              className="p-2 sm:p-2.5 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-purple-800/60 hover:border-purple-500 text-left transition-all cursor-pointer flex items-center gap-2"
            >
              <div className="w-7 h-7 rounded-lg bg-purple-950/80 border border-purple-700/60 flex items-center justify-center shrink-0">
                <Crown className="w-3.5 h-3.5 text-purple-400" />
              </div>
              <div className="min-w-0">
                <div className="font-cinzel text-xs font-bold text-slate-100 truncate">Custom Room</div>
                <div className="text-[9px] text-slate-400 truncate">Maps & Hazards</div>
              </div>
            </button>

            {/* Weapon Loadouts */}
            <button
              onClick={() => {
                onSelectScreen('loadouts');
                sounds.playClick();
              }}
              className="p-2 sm:p-2.5 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-cyan-800/60 hover:border-cyan-500 text-left transition-all cursor-pointer flex items-center gap-2"
            >
              <div className="w-7 h-7 rounded-lg bg-cyan-950/80 border border-cyan-700/60 flex items-center justify-center shrink-0">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <div className="min-w-0">
                <div className="font-cinzel text-xs font-bold text-slate-100 truncate">Loadouts</div>
                <div className="text-[9px] text-slate-400 truncate">Build Grimoire</div>
              </div>
            </button>

            {/* Weapon Codex Catalog */}
            <button
              onClick={() => {
                onSelectScreen('collection');
                sounds.playClick();
              }}
              className="p-2 sm:p-2.5 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-emerald-800/60 hover:border-emerald-500 text-left transition-all cursor-pointer flex items-center gap-2"
            >
              <div className="w-7 h-7 rounded-lg bg-emerald-950/80 border border-emerald-700/60 flex items-center justify-center shrink-0">
                <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="min-w-0">
                <div className="font-cinzel text-xs font-bold text-slate-100 truncate">Staff Codex</div>
                <div className="text-[9px] text-slate-400 truncate">Catalog & Lore</div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Footer Info - Clean, Ad-Free, Fits on Screen */}
      <div className="w-full flex items-center justify-between pt-2 border-t border-slate-900 text-[11px] text-slate-500 z-10 shrink-0">
        <div>
          <span>Wizard Valley · Arcane Sorcery</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sounds.playClick();
              setIsTutorialOpen(true);
            }}
            className="hover:text-amber-400 transition-colors cursor-pointer flex items-center gap-1"
          >
            <HelpCircle className="w-3 h-3" />
            <span>How to Play</span>
          </button>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Auto-Saved</span>
          </div>
        </div>
      </div>

      {/* Primordial Element Sanctum Modal */}
      <ElementSanctumModal
        isOpen={isSanctumOpen}
        onClose={() => setIsSanctumOpen(false)}
      />

      {/* Interactive Academy Tutorial Modal */}
      <TutorialModal
        isOpen={isTutorialOpen}
        onClose={() => setIsTutorialOpen(false)}
        onStartQuickPlay={() => onSelectScreen('arena')}
      />
    </div>
  );
};
