import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Check, 
  Palette, 
  User, 
  Shield, 
  Wand2, 
  Flame, 
  Zap, 
  Crown,
  Eye,
  Coins,
  Gem,
  Award
} from 'lucide-react';
import { useGameSave } from '../context/GameSaveContext';
import { COMBAT_ACCESSORIES_CATALOG, getAccessoryByIdOrName } from '../data/accessoriesData';
import { sounds } from '../utils/audio';

interface CharacterCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'robes' | 'gear' | 'auras' | 'relics' | 'identity';
}

const ROBE_COLOR_PRESETS = [
  { name: 'Abyssal Violet', color: '#9333ea' },
  { name: 'Infernal Crimson', color: '#dc2626' },
  { name: 'Frost Azure', color: '#2563eb' },
  { name: 'Verdant Sylvan', color: '#16a34a' },
  { name: 'Solar Amber', color: '#d97706' },
  { name: 'Void Obsidian', color: '#18181b' },
  { name: 'Celestial Pearl', color: '#e2e8f0' },
  { name: 'Storm Electric', color: '#0891b2' },
];

const AURA_COLOR_PRESETS = [
  { name: 'Arcane Purple', color: '#a855f7' },
  { name: 'Hellfire Red', color: '#ef4444' },
  { name: 'Glacial Cyan', color: '#38bdf8' },
  { name: 'Leyline Gold', color: '#facc15' },
  { name: 'Emerald Gaia', color: '#4ade80' },
  { name: 'Void Abyss', color: '#6b21a8' },
];

const HAT_OPTIONS = [
  { id: 'hat_cap', name: 'Apprentice Pointed Hat', icon: '🧙' },
  { id: 'hat_crown', name: 'Archon Rune Crown', icon: '👑' },
  { id: 'hat_helm', name: 'Battlemage Crest', icon: '⛑️' },
  { id: 'hat_hood', name: 'Shadow Weaver Cowl', icon: '🥷' },
];

const STAFF_VISUALS = [
  { id: 'staff_wand', name: 'Prismatic Scepter', icon: '🪄' },
  { id: 'staff_arcane', name: 'Greatstaff of the Leyline', icon: '⚡' },
  { id: 'staff_orb', name: 'Floating Void Orb', icon: '🔮' },
  { id: 'staff_blade', name: 'Spellblade Scythe', icon: '🗡️' },
];

const BACK_OPTIONS = [
  { id: 'back_none', name: 'None (Clean Mantle)', icon: '🚫' },
  { id: 'back_wings', name: 'Ethereal Mana Wings', icon: '🪽' },
  { id: 'back_dragon', name: 'Crimson Dragon Wings', icon: '🐲' },
  { id: 'back_orbs', name: 'Orbiting Leyline Orbs', icon: '🔮' },
  { id: 'back_cape', name: 'Velvet Runed Cape', icon: '🧣' },
  { id: 'back_pet', name: 'Familiar Pet Companion', icon: '🐱' },
];

const TRAIL_OPTIONS = [
  { id: 'trail_stardust', name: 'Stardust Sparkles', icon: '✨' },
  { id: 'trail_flames', name: 'Cinder Embers', icon: '🔥' },
  { id: 'trail_lightning', name: 'Electric Static', icon: '⚡' },
  { id: 'trail_frost', name: 'Glacial Mist', icon: '❄️' },
  { id: 'trail_shadow', name: 'Shadow Smoke', icon: '💨' },
];

export const CharacterCustomizerModal: React.FC<CharacterCustomizerModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'robes',
}) => {
  const { 
    saveData, 
    updateCosmetics, 
    updateCharacterName,
    equipAccessory,
    unequipAccessory,
    buyCombatAccessory 
  } = useGameSave();
  const char = saveData.character;

  const [activeTab, setActiveTab] = useState<'robes' | 'gear' | 'auras' | 'relics' | 'identity'>(initialTab);
  const [nameInput, setNameInput] = useState(char.name);
  const [actionNotice, setActionNotice] = useState<{ text: string; isError?: boolean } | null>(null);

  if (!isOpen) return null;

  const showNotice = (text: string, isError = false) => {
    setActionNotice({ text, isError });
    setTimeout(() => setActionNotice(null), 3500);
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    updateCharacterName(nameInput);
    sounds.playUpgrade();
    showNotice('Wizard Name Updated!');
  };

  const equippedAccessoryIds = char.equippedAccessories || saveData.accessories || ['apprentice_ring'];
  const ownedAccessories = saveData.accessories || ['apprentice_ring'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-amber-500/50 rounded-2xl max-w-2xl w-full p-6 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-cinzel text-slate-100 flex items-center gap-2">
                <span>Wizard Atelier & Reliquary</span>
                <span className="text-xs px-2 py-0.5 rounded bg-purple-900/50 border border-purple-600/40 text-purple-300">
                  Customizer
                </span>
              </h2>
              <p className="text-xs text-slate-400">Personalize appearance and attune battle-enchanted accessories</p>
            </div>
          </div>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Preview Avatar Box */}
        <div className="my-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div
              className="relative w-14 h-14 rounded-full flex items-center justify-center border-2 border-amber-400/80 shadow-lg shrink-0"
              style={{
                backgroundColor: char.robeColor || '#9333ea',
                boxShadow: `0 0 ${char.glowIntensity || 16}px ${char.auraColor || '#a855f7'}`,
              }}
            >
              <span className="text-2xl select-none">
                {HAT_OPTIONS.find(h => h.id === char.hat)?.icon || '🧙'}
              </span>
              <div 
                className="absolute -bottom-1 -right-1 text-sm bg-slate-900 rounded-full p-0.5 border border-amber-400"
              >
                {STAFF_VISUALS.find(s => s.id === char.staffVisual)?.icon || '🪄'}
              </div>
            </div>

            <div className="min-w-0">
              <div className="text-sm font-bold font-cinzel text-slate-100 flex items-center gap-2">
                <span className="truncate">{char.name}</span>
                <span className="text-xs font-mono font-normal text-amber-400 shrink-0">Lv. {char.level}</span>
              </div>
              <div className="text-xs text-slate-400 truncate">{char.title}</div>
              
              {/* Equipped combat accessories preview */}
              <div className="flex items-center gap-1.5 mt-1">
                {equippedAccessoryIds.map((accId, idx) => {
                  const meta = getAccessoryByIdOrName(accId);
                  return (
                    <span 
                      key={idx} 
                      title={meta?.name || accId}
                      className="px-1.5 py-0.5 bg-slate-900 border border-amber-500/40 rounded text-[10px] text-amber-300 font-medium flex items-center gap-1"
                    >
                      <span>{meta?.icon || '💍'}</span>
                      <span className="truncate max-w-[80px]">{meta?.name.split(' ')[0] || accId}</span>
                    </span>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="text-right text-xs text-slate-400 shrink-0 hidden sm:block">
            <div>Back: <strong className="text-slate-200">{BACK_OPTIONS.find(b => b.id === char.back)?.name.split(' ')[0]}</strong></div>
            <div>Trail: <strong className="text-cyan-300">{TRAIL_OPTIONS.find(t => t.id === char.trail)?.name.split(' ')[0]}</strong></div>
            <div className="text-amber-400 font-mono mt-0.5">💰 {saveData.economy.coins.toLocaleString()} G</div>
          </div>
        </div>

        {/* Action Notice Banner */}
        {actionNotice && (
          <div className={`mb-3 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-between transition-all ${
            actionNotice.isError ? 'bg-red-950/80 border border-red-800 text-red-300' : 'bg-emerald-950/80 border border-emerald-800 text-emerald-300'
          }`}>
            <span>{actionNotice.text}</span>
            <button onClick={() => setActionNotice(null)} className="text-slate-400 hover:text-white ml-2">✕</button>
          </div>
        )}

        {/* Category Tabs */}
        <div className="flex border-b border-slate-800 gap-1 sm:gap-2 mb-3 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => { sounds.playClick(); setActiveTab('relics'); }}
            className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'relics'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>💍</span>
            <span>Relics & Accessories</span>
          </button>
          <button
            onClick={() => { sounds.playClick(); setActiveTab('robes'); }}
            className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer shrink-0 ${
              activeTab === 'robes'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Robes & Colors
          </button>
          <button
            onClick={() => { sounds.playClick(); setActiveTab('gear'); }}
            className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer shrink-0 ${
              activeTab === 'gear'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Headwear, Staff & Back
          </button>
          <button
            onClick={() => { sounds.playClick(); setActiveTab('auras'); }}
            className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer shrink-0 ${
              activeTab === 'auras'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Auras & Trails
          </button>
          <button
            onClick={() => { sounds.playClick(); setActiveTab('identity'); }}
            className={`pb-2 px-3 border-b-2 transition-colors cursor-pointer shrink-0 ${
              activeTab === 'identity'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Name & Title
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4 text-xs">
          {activeTab === 'relics' && (
            <div className="space-y-4">
              {/* Equipped Relic Slots */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-200 flex items-center gap-1.5 font-cinzel">
                    <span>Active Combat Relics ({equippedAccessoryIds.length}/3 Slots)</span>
                  </span>
                  <span className="text-[11px] text-slate-400">Bonuses activate in Arena battles</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[0, 1, 2].map(slotIdx => {
                    const accId = equippedAccessoryIds[slotIdx];
                    const item = accId ? getAccessoryByIdOrName(accId) : undefined;
                    return (
                      <div 
                        key={slotIdx}
                        className={`p-2.5 rounded-lg border flex flex-col justify-between ${
                          item 
                            ? 'bg-amber-950/20 border-amber-600/50' 
                            : 'bg-slate-900/60 border-dashed border-slate-800 text-slate-500'
                        }`}
                      >
                        {item ? (
                          <>
                            <div>
                              <div className="flex items-center justify-between">
                                <span className="text-lg">{item.icon}</span>
                                <span className="text-[10px] px-1.5 py-0.5 rounded font-bold uppercase bg-amber-950 border border-amber-700/60 text-amber-300">
                                  {item.type}
                                </span>
                              </div>
                              <div className="font-bold text-slate-100 mt-1 truncate">{item.name}</div>
                              <div className="text-[11px] text-emerald-400 mt-0.5 leading-snug">{item.effectSummary}</div>
                            </div>
                            <button
                              onClick={() => {
                                unequipAccessory(item.id);
                                showNotice(`Unequipped ${item.name}`);
                              }}
                              className="mt-2 w-full py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded text-[11px] font-semibold cursor-pointer transition-colors"
                            >
                              Unequip
                            </button>
                          </>
                        ) : (
                          <div className="h-20 flex flex-col items-center justify-center text-center">
                            <span className="text-slate-600 text-xl">+</span>
                            <span className="text-[11px] text-slate-500">Empty Slot</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* All Relics Catalog */}
              <div>
                <label className="block text-slate-300 font-semibold mb-2">Relic Vault & Shop</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {COMBAT_ACCESSORIES_CATALOG.map(acc => {
                    const isOwned = ownedAccessories.includes(acc.id) || ownedAccessories.includes(acc.name);
                    const isEquipped = equippedAccessoryIds.includes(acc.id) || equippedAccessoryIds.includes(acc.name);
                    const canAfford = saveData.economy.coins >= acc.cost.coins && saveData.economy.materials.magic_dust >= acc.cost.magicDust;
                    const meetsLevel = saveData.character.level >= acc.levelReq;

                    return (
                      <div
                        key={acc.id}
                        className={`p-3 rounded-xl border flex flex-col justify-between transition-all ${
                          isEquipped
                            ? 'bg-amber-950/30 border-amber-500 ring-1 ring-amber-500/50'
                            : isOwned
                            ? 'bg-slate-950 border-slate-800 hover:border-slate-700'
                            : 'bg-slate-950/70 border-slate-800/80 opacity-90'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">{acc.icon}</span>
                              <div>
                                <div className="font-bold text-slate-100 flex items-center gap-1.5 font-cinzel">
                                  <span>{acc.name}</span>
                                </div>
                                <span className={`text-[10px] font-semibold ${
                                  acc.rarity === 'Legendary' ? 'text-amber-400' : acc.rarity === 'Epic' ? 'text-purple-400' : 'text-blue-400'
                                }`}>
                                  {acc.rarity} {acc.type}
                                </span>
                              </div>
                            </div>
                            <span className="text-[10px] text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                              Lv.{acc.levelReq}
                            </span>
                          </div>

                          <p className="text-[11px] text-slate-400 line-clamp-2 my-1.5 leading-relaxed">{acc.description}</p>
                          <div className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-900/60 px-2 py-1 rounded">
                            ✨ {acc.effectSummary}
                          </div>
                        </div>

                        <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                          {isOwned ? (
                            isEquipped ? (
                              <button
                                onClick={() => {
                                  unequipAccessory(acc.id);
                                  showNotice(`Unequipped ${acc.name}`);
                                }}
                                className="w-full py-1.5 bg-amber-950/70 border border-amber-600/70 text-amber-300 rounded-lg font-bold text-xs cursor-pointer hover:bg-amber-900 transition-colors"
                              >
                                Equipped (Click to Unequip)
                              </button>
                            ) : (
                              <button
                                onClick={() => {
                                  equipAccessory(acc.id);
                                  showNotice(`Equipped ${acc.name}`);
                                }}
                                className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 rounded-lg font-bold text-xs cursor-pointer transition-colors shadow"
                              >
                                Equip to Battle
                              </button>
                            )
                          ) : (
                            <div className="w-full flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2 text-[11px] font-mono">
                                <span className="text-amber-400">💰 {acc.cost.coins}</span>
                                {acc.cost.magicDust > 0 && <span className="text-cyan-300">✨ {acc.cost.magicDust} Dust</span>}
                              </div>
                              <button
                                onClick={() => {
                                  const res = buyCombatAccessory(acc.id);
                                  showNotice(res.message, !res.success);
                                }}
                                disabled={!canAfford || !meetsLevel}
                                className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors cursor-pointer ${
                                  !meetsLevel
                                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                                    : canAfford
                                    ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow'
                                    : 'bg-slate-800 text-slate-400 border border-slate-700 cursor-not-allowed'
                                }`}
                              >
                                {!meetsLevel ? `Need Lv.${acc.levelReq}` : canAfford ? 'Attune & Buy' : 'Short Funds'}
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'robes' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-2">Robe Fabric Color</label>
                <div className="grid grid-cols-4 gap-2">
                  {ROBE_COLOR_PRESETS.map(preset => (
                    <button
                      key={preset.color}
                      onClick={() => {
                        updateCosmetics('robeColor', preset.color);
                        sounds.playClick();
                      }}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                        char.robeColor === preset.color
                          ? 'border-amber-400 bg-amber-400/10 text-white font-bold ring-1 ring-amber-400'
                          : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full border border-slate-700 shrink-0"
                        style={{ backgroundColor: preset.color }}
                      />
                      <span className="truncate text-[11px]">{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-2">Custom Hex Code</label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={char.robeColor || '#9333ea'}
                    onChange={e => updateCosmetics('robeColor', e.target.value)}
                    className="w-10 h-9 rounded bg-slate-950 border border-slate-800 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={char.robeColor || '#9333ea'}
                    onChange={e => updateCosmetics('robeColor', e.target.value)}
                    className="px-3 py-2 rounded bg-slate-950 border border-slate-800 text-slate-200 font-mono text-xs w-32 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'gear' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-2">Arcane Headwear</label>
                <div className="grid grid-cols-2 gap-2">
                  {HAT_OPTIONS.map(hat => (
                    <button
                      key={hat.id}
                      onClick={() => {
                        updateCosmetics('hat', hat.id);
                        sounds.playClick();
                      }}
                      className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                        char.hat === hat.id
                          ? 'border-amber-400 bg-amber-400/10 text-white font-bold ring-1 ring-amber-400'
                          : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-xl">{hat.icon}</span>
                      <span className="truncate">{hat.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-2">Staff Style</label>
                <div className="grid grid-cols-2 gap-2">
                  {STAFF_VISUALS.map(staff => (
                    <button
                      key={staff.id}
                      onClick={() => {
                        updateCosmetics('staffVisual', staff.id);
                        sounds.playClick();
                      }}
                      className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                        char.staffVisual === staff.id
                          ? 'border-amber-400 bg-amber-400/10 text-white font-bold ring-1 ring-amber-400'
                          : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-xl">{staff.icon}</span>
                      <span className="truncate">{staff.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-2">Back Accessory & Wings</label>
                <div className="grid grid-cols-2 gap-2">
                  {BACK_OPTIONS.map(back => (
                    <button
                      key={back.id}
                      onClick={() => {
                        updateCosmetics('back', back.id);
                        sounds.playClick();
                      }}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                        char.back === back.id
                          ? 'border-cyan-400 bg-cyan-400/10 text-cyan-200 font-bold ring-1 ring-cyan-400'
                          : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-base">{back.icon}</span>
                      <span className="truncate">{back.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'auras' && (
            <div className="space-y-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-2">Arcane Aura Glow</label>
                <div className="grid grid-cols-3 gap-2">
                  {AURA_COLOR_PRESETS.map(preset => (
                    <button
                      key={preset.color}
                      onClick={() => {
                        updateCosmetics('auraColor', preset.color);
                        sounds.playClick();
                      }}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                        char.auraColor === preset.color
                          ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                          : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full shrink-0 shadow"
                        style={{ backgroundColor: preset.color, boxShadow: `0 0 8px ${preset.color}` }}
                      />
                      <span className="truncate text-[11px]">{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-slate-300 font-semibold">Glow Intensity</label>
                  <span className="text-amber-400 font-mono">{char.glowIntensity || 16}px</span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="32"
                  value={char.glowIntensity || 16}
                  onChange={e => updateCosmetics('glowIntensity', parseInt(e.target.value, 10))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-2">Arcane Step Trail</label>
                <div className="grid grid-cols-2 gap-2">
                  {TRAIL_OPTIONS.map(trail => (
                    <button
                      key={trail.id}
                      onClick={() => {
                        updateCosmetics('trail', trail.id);
                        sounds.playClick();
                      }}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                        char.trail === trail.id
                          ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                          : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <span className="text-base">{trail.icon}</span>
                      <span className="truncate">{trail.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'identity' && (
            <div className="space-y-4">
              <form onSubmit={handleSaveName} className="space-y-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Character Name</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={nameInput}
                      onChange={e => setNameInput(e.target.value)}
                      maxLength={24}
                      className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-100 font-semibold focus:outline-none focus:border-amber-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg cursor-pointer transition-colors"
                    >
                      Save Name
                    </button>
                  </div>
                </div>
              </form>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-slate-400 text-[11px]">Honored Title</div>
                <div className="text-sm font-cinzel font-bold text-amber-300">{char.title}</div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Titles are bestowed upon completing story chapters and defeating raid bosses in Wizard Valley.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex justify-end gap-3 mt-3">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer shadow-lg transition-colors"
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
};

