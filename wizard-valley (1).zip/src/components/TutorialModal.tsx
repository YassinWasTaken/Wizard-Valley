import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle, 
  Flame, 
  Zap, 
  Shield, 
  Crosshair, 
  MousePointer, 
  Award,
  BookOpen
} from 'lucide-react';
import { useGameSave } from '../context/GameSaveContext';
import { PRIMORDIAL_ELEMENTS_DATA, PrimordialElementDetail } from '../data/elementsData';
import { sounds } from '../utils/audio';

interface TutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartQuickPlay?: () => void;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({
  isOpen,
  onClose,
  onStartQuickPlay,
}) => {
  const { saveData, claimTutorialReward } = useGameSave();
  const [currentStep, setCurrentStep] = useState(0);
  const [dummyHp, setDummyHp] = useState(100);
  const [dummyHitText, setDummyHitText] = useState<{ text: string; color: string } | null>(null);
  const [selectedElemId, setSelectedElemId] = useState('Fire');
  const [rewardClaimed, setRewardClaimed] = useState(saveData.progression.storyProgress > 0);

  if (!isOpen) return null;

  const steps = [
    {
      title: 'Movement & Dodging',
      subtitle: 'Survive in the Arena',
      icon: <Shield className="w-5 h-5 text-amber-400" />,
      content: (
        <div className="space-y-4">
          <p className="text-slate-300 text-sm leading-relaxed">
            Move your wizard freely across the arena using standard keys or touch controls. Stay mobile to avoid getting surrounded by monster swarms!
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="flex flex-col gap-1 items-center">
                <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-bold font-mono text-amber-300">W</div>
                <div className="flex gap-1">
                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-bold font-mono text-amber-300">A</div>
                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-bold font-mono text-amber-300">S</div>
                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-bold font-mono text-amber-300">D</div>
                </div>
              </div>
              <div>
                <div className="font-bold text-slate-100 text-xs">WASD or Arrow Keys</div>
                <div className="text-[11px] text-slate-400">Walk in 8 directions (also supports mobile touch drag).</div>
              </div>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="w-20 h-9 rounded-lg bg-slate-900 border border-amber-600/60 flex items-center justify-center font-bold font-mono text-xs text-amber-300 shadow">
                SPACE
              </div>
              <div>
                <div className="font-bold text-amber-300 text-xs">Dash of Invulnerability</div>
                <div className="text-[11px] text-slate-400">Burst forward through enemy lines and hazard rings unharmed!</div>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: 'Aim & Cast Magic',
      subtitle: 'Staff Attacks & Mana',
      icon: <Crosshair className="w-5 h-5 text-cyan-400" />,
      content: (
        <div className="space-y-4">
          <p className="text-slate-300 text-sm leading-relaxed">
            Your equipped staff continuously casts elemental projectiles toward your aiming target.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-cyan-950/60 border border-cyan-700/60 flex items-center justify-center text-cyan-300 shrink-0">
                <MousePointer className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-slate-100 text-xs">Aim & Hold Left-Click</div>
                <div className="text-[11px] text-slate-400">Aim with your cursor. Hold Left-Click (or touch screen) for rapid continuous fire.</div>
              </div>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-950/60 border border-blue-700/60 flex items-center justify-center text-blue-300 shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold text-slate-100 text-xs">Mana Pool (MP)</div>
                <div className="text-[11px] text-slate-400">Spells cost mana, which regenerates naturally. Blue potions grant instant refills.</div>
              </div>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: '8 Primordial Elements',
      subtitle: 'Counter Enemy Weaknesses',
      icon: <Flame className="w-5 h-5 text-orange-400" />,
      content: (
        <div className="space-y-3">
          <p className="text-slate-300 text-xs leading-relaxed">
            Switch elements instantly with hotkeys <strong className="text-amber-400 font-mono">[1] to [8]</strong> or by clicking the bottom element bar:
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {PRIMORDIAL_ELEMENTS_DATA.slice(0, 8).map((e: PrimordialElementDetail) => (
              <div key={e.id} className="p-2 bg-slate-950 rounded-xl border border-slate-800 flex items-center gap-2">
                <span className="text-xl">{e.icon}</span>
                <div className="min-w-0">
                  <div className="font-bold text-slate-200 text-xs font-cinzel flex items-center gap-1">
                    <span className="truncate">{e.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">[{e.keyNum}]</span>
                  </div>
                  <div className="text-[10px] text-emerald-400 truncate">{e.perkName}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-2.5 rounded-xl bg-amber-950/30 border border-amber-600/40 text-[11px] text-amber-200 flex items-center gap-2">
            <span className="text-base">💡</span>
            <span><strong>Pro Tip:</strong> Matching enemy elemental weaknesses deals up to <strong>+50% bonus damage</strong> and inflicts freeze, burn, or chain shock!</span>
          </div>
        </div>
      ),
    },
    {
      title: 'Interactive Spell Practice',
      subtitle: 'Try Hitting the Training Dummy',
      icon: <Sparkles className="w-5 h-5 text-purple-400" />,
      content: (
        <div className="space-y-4">
          <p className="text-slate-300 text-xs leading-relaxed">
            Select an element below and test your spells on the Citadel Training Dummy:
          </p>

          {/* Elemental Picker */}
          <div className="flex flex-wrap gap-1.5 justify-center">
            {PRIMORDIAL_ELEMENTS_DATA.slice(0, 8).map((el: PrimordialElementDetail) => (
              <button
                key={el.id}
                onClick={() => {
                  setSelectedElemId(el.id);
                  sounds.playCastSpell(el.id);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  selectedElemId === el.id
                    ? 'bg-amber-500 text-slate-950 shadow-md font-bold scale-105'
                    : 'bg-slate-950 border border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <span>{el.icon}</span>
                <span>{el.name}</span>
              </button>
            ))}
          </div>

          {/* Target Dummy Box */}
          <div className="relative p-5 rounded-2xl bg-slate-950 border-2 border-slate-800 flex flex-col items-center justify-center overflow-hidden">
            <div className="text-5xl select-none animate-pulse">🎯</div>
            <div className="font-cinzel font-bold text-slate-200 mt-1">Leyline Training Golem</div>
            
            {/* Health Bar */}
            <div className="w-48 h-3 bg-slate-900 rounded-full border border-slate-700 mt-2 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-red-600 to-amber-400 transition-all duration-150"
                style={{ width: `${dummyHp}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-slate-400 mt-0.5">{dummyHp} / 100 HP</span>

            {/* Hit Floating Text */}
            {dummyHitText && (
              <div 
                className="absolute top-4 text-base font-bold font-cinzel animate-bounce"
                style={{ color: dummyHitText.color }}
              >
                {dummyHitText.text}
              </div>
            )}

            <button
              onClick={() => {
                const dmg = Math.floor(18 + Math.random() * 14);
                const elem = PRIMORDIAL_ELEMENTS_DATA.find((e: PrimordialElementDetail) => e.id === selectedElemId) || PRIMORDIAL_ELEMENTS_DATA[0];
                sounds.playCastSpell(elem.id);
                setDummyHp(prev => Math.max(10, prev - dmg <= 0 ? 100 : prev - dmg));
                setDummyHitText({ text: `💥 -${dmg} ${elem.name}!`, color: elem.color });
                setTimeout(() => setDummyHitText(null), 1000);
              }}
              className="mt-3 px-4 py-2 bg-gradient-to-r from-purple-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer transition-all active:scale-95"
            >
              Cast {selectedElemId} Spell!
            </button>
          </div>
        </div>
      ),
    },
    {
      title: 'Relics, Leveling & Forging',
      subtitle: 'Claim Graduate Reward',
      icon: <Award className="w-5 h-5 text-emerald-400" />,
      content: (
        <div className="space-y-4 text-xs">
          <p className="text-slate-300 leading-relaxed">
            You're now ready for Citadel battle! Here is your quick checklist for victory:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-xl mb-1">🧲</div>
              <div className="font-bold text-slate-100">Magnetic Relics</div>
              <p className="text-slate-400 text-[11px] mt-1 leading-snug">
                Equip rings & amulets in the Atelier to automatically suck in dropped gold and crystals.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-xl mb-1">🌟</div>
              <div className="font-bold text-slate-100">Leveling Up</div>
              <p className="text-slate-400 text-[11px] mt-1 leading-snug">
                Gain XP orbs during battle to level up on the fly and boost your Max HP, MP, and damage.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-xl mb-1">⚒️</div>
              <div className="font-bold text-slate-100">Arcane Forge</div>
              <p className="text-slate-400 text-[11px] mt-1 leading-snug">
                Craft and evolve legendary weapons like Flame Staff, Storm Caller, and Void Scepter.
              </p>
            </div>
          </div>

          {/* Apprentice Graduation Gift */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/60 to-purple-950/60 border border-amber-500/50 flex items-center justify-between gap-4">
            <div>
              <div className="font-bold text-amber-300 font-cinzel text-sm flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" />
                <span>Apprentice Initiation Bounty</span>
              </div>
              <div className="text-[11px] text-slate-300 mt-0.5">
                Reward: <strong>+300 Citadel Gold</strong> & <strong>+15 Magic Dust</strong>
              </div>
            </div>

            <button
              onClick={() => {
                if (!rewardClaimed) {
                  claimTutorialReward();
                  setRewardClaimed(true);
                }
              }}
              disabled={rewardClaimed}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                rewardClaimed
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-700/60 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md animate-pulse'
              }`}
            >
              {rewardClaimed ? '✓ Claimed' : 'Claim Bounty'}
            </button>
          </div>
        </div>
      ),
    },
  ];

  const current = steps[currentStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-amber-500/50 rounded-2xl max-w-xl w-full p-6 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-amber-500 p-0.5 shadow">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <BookOpen className="w-4 h-4 text-amber-400" />
              </div>
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-cinzel text-slate-100 flex items-center gap-2">
                <span>Citadel Academy Tutorial</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 border border-amber-600/50 text-amber-300 font-sans">
                  Step {currentStep + 1} of {steps.length}
                </span>
              </h2>
              <p className="text-xs text-slate-400">{current.subtitle}</p>
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Indicators */}
        <div className="flex gap-1.5 my-3.5">
          {steps.map((s, idx) => (
            <button
              key={idx}
              onClick={() => {
                sounds.playClick();
                setCurrentStep(idx);
              }}
              className={`h-1.5 flex-1 rounded-full transition-all cursor-pointer ${
                idx === currentStep
                  ? 'bg-amber-400 shadow-[0_0_8px_#f59e0b]'
                  : idx < currentStep
                  ? 'bg-emerald-500'
                  : 'bg-slate-800'
              }`}
              title={s.title}
            />
          ))}
        </div>

        {/* Step Body */}
        <div className="flex-1 overflow-y-auto pr-1 py-1">
          <div className="flex items-center gap-2 mb-2 font-bold font-cinzel text-slate-100 text-sm">
            {current.icon}
            <span>{current.title}</span>
          </div>
          {current.content}
        </div>

        {/* Navigation Buttons */}
        <div className="pt-3.5 border-t border-slate-800 flex items-center justify-between gap-3 mt-3">
          <button
            onClick={() => {
              sounds.playClick();
              setCurrentStep(prev => Math.max(0, prev - 1));
            }}
            disabled={currentStep === 0}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
              currentStep === 0
                ? 'opacity-40 cursor-not-allowed text-slate-600'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          <div className="flex items-center gap-2">
            {currentStep < steps.length - 1 ? (
              <button
                onClick={() => {
                  sounds.playClick();
                  setCurrentStep(prev => Math.min(steps.length - 1, prev + 1));
                }}
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <span>Next Step</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => {
                  sounds.playClick();
                  onClose();
                  if (onStartQuickPlay) onStartQuickPlay();
                }}
                className="px-5 py-2 bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 text-slate-950 font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer transition-all animate-pulse"
              >
                <span>⚔️ Jump into Battle!</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
